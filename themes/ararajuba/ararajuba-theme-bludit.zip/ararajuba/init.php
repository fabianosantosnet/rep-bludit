<?php
/* $ts = gmdate("D, d M Y H:i:s") . " GMT";
header("Expires: $ts");
header("Last-Modified: $ts");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");
	//set ini files
	
// Debug mode
// Change to FALSE, for prevent warning or errors on browser
	define('DEBUG_MODEFS', TRUE);
	define('DEBUG_TYPE', 'INFO'); // INFO, TRACE
	error_reporting(1); // Turn off all error reporting

	if (DEBUG_MODEFS) 
	{
		// Turn on all error reporting
		ini_set("display_errors", 1);
		ini_set('display_startup_errors',1);
		ini_set("html_errors", 1);
		ini_set('log_errors', 1);
		error_reporting(E_ALL | E_STRICT | E_NOTICE);
	}
*/
	## GLOBALS
	
    #FULL DOMAIN AND LOCALPAGE
    $ARARA_FULLDOMAIN_PAGE=DOMAIN.$url->uri();	
	
	#IF YOU WOULD NOT LIKE TO PRINT SOCIAL NETWORKER at FOOTER set false
	$ARARA_PRINT_FOOTER_NETWORKER=true;
	
	$ARARUBA_PAGINATOR_NUMBERS=false;
	
	#default lang
	$ararajuba_lowerLang = strtolower(Theme::lang());
	
	$sizeThumb='226x120'; #set size of thumb ( show article if it hadn't any image  )
	#remove '#' below if you want to control thumbs with control panel
	#$sizeThumb=$site->thumbnailWidth().'x'. $site->thumbnailHeight();
	
	$sizeCover='717x300';

	$nl="\n\t";
	
	#FUNCTIONS
	require_once(THEME_DIR_PHP.'functions.php');	
?>
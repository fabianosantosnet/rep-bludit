<?php
$arb_head='
  <html lang="'. $ararajuba_lowerLang .'">
   <head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">  
	<meta charset="utf-8">
'.$nl;
	
	    $arb_head .= Theme::viewport("width=device-width, initial-scale=1, shrink-to-fit=no").$nl.
					Theme::metaTagTitle().$nl.
					Theme::metaTagDescription(). $nl.
					Theme::favicon('img/favicon.png').$nl.
					Theme::css('css/style.css'); 
					
					echo $arb_head.$nl.
					'<script src="'. HTML_PATH_THEME_JS.'scripts.js"'.' defer></script>'.$nl.'
    <script type="application/ld+json">
     {
       "@context": "http://schema.org",
       "@type": "WebSite",
       "name": "'.$site->title().'",
      "alternateName": "'. $site->description().'",
      "url": "'. $site->url().'"
    }
   </script>   
'.$nl;				

	Theme::plugins('siteHead');								
?>
   </head>


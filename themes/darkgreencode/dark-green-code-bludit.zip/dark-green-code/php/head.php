<?php defined('BLUDIT') or die('Bludit CMS');

	$_head='<!DOCTYPE html>
<html lang="'. $lowerLang .'">

  <head>
  
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">  
    '.Theme::charset('utf-8');
	
	#Theme::src($file) 	#Theme::keywords($keywords)
	
	$_head .= Theme::viewport("width=device-width, initial-scale=1").$nl.
				Theme::metaTagTitle().$nl.
				Theme::metaTagDescription(). $__TAB.
				'<meta name="author" content="'.$authorName.'">'.$nl.$nl.
				Theme::favicon('img/favicon.png'). $__TAB.
				Theme::css('css/style.css'); 
				
	echo $_head.$nl;
	
	Theme::plugins('siteHead');
	
	echo $nl.'<script src="'. HTML_PATH_THEME_JS.'scripts.js"'.' defer></script>'.$nl.'
    <script type="application/ld+json">
     {
       "@context": "http://schema.org",
       "@type": "WebSite",
       "name": "'.$site->title().'",
      "alternateName": "'. $site->description().'",
      "url": "'. $site->url().'"
    }
   </script>   
'.$nl;
?>
   </head>  
  
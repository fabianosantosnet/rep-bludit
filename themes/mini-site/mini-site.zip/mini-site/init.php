<?php /*

#Remove this comments only for debug purposes

$ts = gmdate("D, d M Y H:i:s") . " GMT";
header("Expires: $ts");
header("Last-Modified: $ts");
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");
	//set ini files
	
// Debug mode
// Change to FALSE, for prevent warning or errors on browser
	define('DEBUG_MODEFS', TRUE);
	define('DEBUG_TYPE', 'INFO'); // INFO, TRACE
	error_reporting(1); // Turn off all error reporting

	if (DEBUG_MODEFS) 
	{
		// Turn on all error reporting
		ini_set("display_errors", 1);
		ini_set('display_startup_errors',1);
		ini_set("html_errors", 1);
		ini_set('log_errors', 1);
		error_reporting(E_ALL | E_STRICT | E_NOTICE);
	}
*/
	## GLOBALS	
	$authorName='Mini Site';	 # Change site's author name 
	
	#default lang
	$lowerLang = strtolower(Theme::lang());	
		
	#for home page
	$PAGINATOR_NUMBERS=false;
	$IS_DESC_BEFORE_COVER_IMAGE=false;
	$IS_DESC_AFTER_COVER_IMAGE=true;	
	$NUMBER_STICKY_PAGES_HOME_PAGE=5; // limit the number of STICKY PAGES - '-1' is the same as all pages
	
	#for static page (only one is permited if two is true none of them show)
	$IS_DESC_BEFORE_COVER_IMAGE_STATIC=true; 
	$IS_DESC_AFTER_COVER_IMAGE_STATIC=true;
	
	# for all pages - set default image if it is not uploaded 
	$IS_COVER_IMAGE_CALLBACK_SET=true;
	
	#DEFAULT IMAGE CALLBACK
	$_DEFAULT_COVER_IMAGE='https://via.placeholder.com/744x160.png?text=Image%20744x160';
	
	$nl="\n\t";
	
	#FUNCTIONS
	require_once(THEME_DIR_PHP.'functions.php');	
	
	#DEFAULT PAGE NOT FOUND
	if($url->notfound()) {	echo page_info('ERROR', 'ERROR 404', 'Page Not Found'); exit; }	
?>
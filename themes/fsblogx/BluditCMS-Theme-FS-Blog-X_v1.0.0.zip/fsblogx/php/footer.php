<footer class="bottom">
	<div class="container">
		<p><?php echo $site->footer(); ?> <span>| <a target="_blank" href="https://themes.bludit.com">Template FS Blog X</a> | Powered by <a target="_blank" href="https://www.bludit.com"><img class="mini-logo" src="<?php echo DOMAIN_THEME_IMG.'favicon.png'; ?>" alt="Bludit CMS" /></a></span></p>
	</div>
</footer>

<!-- template made by https://git.fabianosantos.net - based on 'Blog X' Template -->
<?php
//Plugin by @fabianosantosnet for BLUDT CMS 2020

class pluginFS_SEO extends Plugin {

	public function init()
	{
		// Fields and default values for the database of this plugin
		$this->dbFields = array
		(
			'fbopenGraphEnabled'=>false,
			'twcardEnabled'=>false,		
			'is_xhtml'=>false,
			'sitemapEnabled'=>false,
			'pingGoogle'=>false, # SITEMAP
			'pingBing'=>false,	 # SITEMAP					
			'fb_AppId'=>'',
			'fb_defaultImage'=>'',
			'fb_page'=>'',
			'fb_description'=>'',
			'tw_defaultImage'=>'',
			'tw_def_desc'=>'',
			'tw_def_page'=>'',			
			'space'=>''
		);
		
		$activePlugins=array();
	}

	public function beforeAll()
	{
		/* SITEMAP */				
		if($this->getValue('sitemapEnabled'))
		{	
			$webhook = 'sitemap.xml';
			if( $this->webhook($webhook) )
			{
				$sitemapFile = $this->workspace().'sitemap.xml';
				$sitemapSize = filesize($sitemapFile);

				// Send XML header
				header('Content-type: text/xml');
				header('Content-length: '.$sitemapSize);

				$doc = new DOMDocument();

				// Workaround for a bug https://bugs.php.net/bug.php?id=62577
				libxml_disable_entity_loader(false);

				// Load XML
				$doc->load($this->workspace().'sitemap.xml');

				libxml_disable_entity_loader(true);

				// Print the XML
				echo $doc->saveXML();

				// Terminate the run successfully
				exit(0);
			}	
		}		
	}
	
	public function form()
	{
		global $L;

		$html  = '
				<style>					
					
					form.plugin-form > div:first-of-type > h2 {padding:1rem;background:#f5f5f5;border-bottom:1rem solid #ccc}
					form.plugin-form > div:first-of-type {margin-top:-0.7rem}
					form.plugin-form > div.align-middle > div {padding:1rem}
					
					div.plgopt {background:#eee;padding:1rem;text-align:right}
					div.plgopt .optionplugin {width:auto !important;display:inline-block;border-radius:0;height:auto;padding:0.1rem}
					div.inlineopt {display:inline}
					div.inlineopt div.plgopt {width:10rem;padding:0;background:transparent;display:inline}
					div.inlineopt div.plgopt .optionplugin {display:inline}
					
					.plgact_message {display:block;padding:1rem;margin:auto;width:400px;background-color:#ffe;color:red;font-size:1rem}
	
					div.plugin-info {background:#f5f5f5;padding:1rem;font-size:0.8rem !important}
					div.plugin-info h2 {padding:0.5rem 1rem;background:#eee;color:#777;text-transform:uppercase;font-size:1.2rem;font-weight:bold;margin:-1rem;margin-bottom:1rem}
					
					div.plugin-info h3.desc {background-color:#ddd;color:#777;margin:-1rem;margin-bottom:2rem;padding:2rem}					
					div.plugin-info h3 {padding:1rem;font-size:1rem}
					
					div.plugin-info div label {}
					div.plugin-info div {clear:both}
					div.plugin-info input[type=text] {border-radius:0;border-color:#ddd;padding:0.4rem;margin-top:-0.3rem;color:#999}
					
					p.copy {background:#eee;padding:1rem;margin:-1rem}
					span.copybased {display:block;font-size:0.7rem;margin-top:1rem;color:#999}
					div.plugin-info span.tip {background:#eee;padding:0.5rem 1rem;font-size:0.7rem;color:#777;margin-top:2px}
					
					.smap {margin-top:-0.2rem;margin:auto;max-width:600px;display:block}
					.smap label {background-color:#efefee;padding:1rem;color:#999}
					.smap label a {color:#999}
					.smap .tip2 {font-size:1rem !important;margin-bottom:1rem}
					.tip3 {background-color:#f0f0f0 !important;margin:auto;display:block;text-align:center;padding:1rem}
					.tip3 code {letter-spacing:1px !important;;}
					.smap .pingopt {margin:auto;width:400px;display:block}
					
					div.plugin-info .w100 {width:100px}
					div.plugin-info .inline {display:inline}
					#spinfo {background:#eee;padding:0.3rem}
				
				</style>
				
				<script>
				window.onload=function()
				{
					function AddSpace()
					{
						var val=parseInt(document.getElementById("spaceinfo").innerHTML);
							val=val+1;
							
							if(val>100) return;
							
						document.getElementById("spaceinfo").innerHTML=val;
						document.getElementById("space").value=document.getElementById("space").value+" ";
					}
					
					function SubSpace()
					{
						var val=parseInt(document.getElementById("spaceinfo").innerHTML);
							val=val-1;
							
							if(val<0) return;
							
						document.getElementById("spaceinfo").innerHTML=val;
						
						sp="";
						for(i=0;i<val;i++) 
							sp+=" ";
						
						document.getElementById("space").value=sp;
					}					
					
					document.getElementById("spaceinfo").innerHTML="'.strlen($this->getValue('space')).'";
					document.getElementById("btnAddSpace").onclick=AddSpace;
					document.getElementById("btnSubSpace").onclick=SubSpace;
				}
				</script>
				
		<div class="plugin-info">
		<h2>'.$L->get('share-configl-name').'</h2>
		<h3 class="desc">'.$L->get('share-configl-description').'</h3>';
		
		$html.='<div>';
		$html.=   $L->get('share-configl-space-desc');
		$html.='  <input type="button" name="btnSubSpace" id="btnSubSpace" value="-"> ';
		$html.='  <input type="button" name="btnAddSpace" id="btnAddSpace" value="+">';		
		$html.='  <span id="spinfo"><span id="spaceinfo">0</span> '.$L->get('space(s) added').'</span>';
		$html.='  <input type="hidden" id="space" name="space" value="'.$this->getValue('space').'">';
		$html.='</div><br>';
		
		$html.= '<div>';
		$html.= $L->get('share-configl-xhtml-desc');
		$html.= '<div class="inlineopt">'.$this->OptionDisableEnable('is_xhtml',false).'</div>';
		$html.= '</div>';
		$html.= '</div><br>';
		$html.='<div class="plugin-info">';
		$html.='<h2>Facebook OpenGraph</h2>
				<h3 class="desc">'.$L->get('fb-info-desc').'</h3>';

		  if ( getPlugin('pluginOpenGraph') ) { $html.= "<span class='plgact_message'>".$L->get('plg-opengraph-already-running')."</span>";}
		  else $html.=  $this->OptionDisableEnable('fbopenGraphEnabled');
		
		$html .= '<div>';
		$html .= '  <label>' . $L->get('fb-app-id') . '</label>';
		$html .= '  <input id="jsfb_AppId" name="fb_AppId" type="text" value="' . $this->getValue('fb_AppId') . '"  placeholder="App ID">';
		$html .= '</div><br>';
		
		$html .= '<div>';
		$html .= '  <label>' . $L->get('fb-default-image') . '</label>';
		$html .= '  <input id="jsfb_defaultImage" name="fb_defaultImage" type="text" value="' . $this->getValue('fb_defaultImage') . '" placeholder="https://">';		
		$html .= '  <span class="tip">'. $L->get('fb-default-image-tip') .' </span>';
		$html .= '</div><br>';
		
		$html .= '<div>';
		$html .= '  <label>' . $L->get('fb-description') . '</label>';
		$html .= '  <input id="jsfb_description" name="fb_description" maxlength="150" type="text" value="' . $this->getValue('fb_description') . '" >';
		$html .= '  <span class="tip">'. $L->get('fb-description-tip') .'</span>';
		$html .= '</div>';
		
		$html .= '<div>';
		$html .= '  <label>' . $L->get('fb-page') . '</label>';
		$html .= '  <input id="jsfb_page" name="fb_page" type="text" value="' . $this->getValue('fb_page') . '" placeholder="https://www.facebook.com/USERNAME">';
		$html .= '  <span class="tip">'. $L->get('fb-page-tip') .'</span>';
		$html .= '</div>';
		
		$html .= '<br><br><br><br>';
		
		$html .= '<div>';
		$html .= '  <h2>Twitter Cards</h2>';
		$html .= '<h3 class="desc">'.$L->get('tw-info-desc').'</h3>';		
		
		  if ( getPlugin('pluginTwitterCards') ) { $html.= "<span class='plgact_message'>".$L->get('plg-twcard-already-running')."</span>";}
		  else $html.= $this->OptionDisableEnable('twcardEnabled');
				
		$html .= '<div>';		
		$html .= '  <label>'.$L->get('tw-default-image').'</label>';
		$html .= '  <input id="jstw_defaultImage" name="tw_defaultImage" type="text" value="'.$this->getValue('tw_defaultImage').'" placeholder="https://">';
		$html .= '  <span class="tip">'. $L->get('tw-image-tip') .'</span>';
		$html .= '</div>';	

		$html .= '<div>';
		$html .= '  <label>' . $L->get('tw-default-description') . '</label>';
		$html .= '  <input id="jstw_def_desc" name="tw_def_desc" maxlength="150" type="text" value="' . $this->getValue('tw_def_desc') . '" >';
		$html .= '  <span class="tip">'. $L->get('tw-default-description-tip') .'</span>';
		$html .= '</div>';
		
		$html .= '<div>';
		$html .= '  <label>' . $L->get('tw-default-page') . '</label>';
		$html .= '  <input id="jstw_def_page" name="tw_def_page" type="text" value="' . $this->getValue('tw_def_page') . '" placeholder="https://twitter.com/USERNAME">';
		$html .= '  <span class="tip">'. $L->get('tw-page-tip') .'</span>';
		$html .= '</div>';
		
		$html .= '</div><br><br><br><br>';		

		$html .= '<h2>'.$L->get('sitemap-title').'</h2>
		<h3 class="desc">'.$L->get('sitemap-description').'</h3>';
		  
		if ( getPlugin('pluginSitemap') ) { $html.= "<span class='plgact_message'>".$L->get('plg-sitemap-already-running')."</span>";} 
		else $html.=  $this->OptionDisableEnable('sitemapEnabled');		
		
		$html .= '<br><div class="smap">';
		
		$html .= '<span class="tip tip2">'.$L->get('ping-tip').'</span>';
		
		$html .= '<div class="pingopt">'.$L->get('Ping Google');		
		$html.=  '<div class="inlineopt">'.$this->OptionDisableEnable('pingGoogle',false).'</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
		
		$html .= $L->get('Ping Bing');	
		$html.=  ' <div class="inlineopt">'.$this->OptionDisableEnable('pingBing',false).'</div></div><br>';		
		$html .= '
		<label>';
		$html .=  $L->get('Sitemap URL:').' <a href="'.DOMAIN_BASE.'sitemap.xml">'.DOMAIN_BASE.'sitemap.xml</a></label>';
		$html .='</div>';		
		
		$html.='<br><hr><br><span class="tip3">'.$L->get('replace-info').'</span><br><br>';
		
		$spc='&nbsp;&nbsp;&nbsp;';
		$html.='<p class="copy">'.$spc.'FS SEO Plugin for BLUDIT CMS by @fabianosantosnet. '.$L->get('send-me-tip').'<br>';
		$html.='<span class="copybased">'.$spc.'This was based on BLUSEO, Twitter Card and OpenGraph Plugins</span></p><br>';
						
						/* Some parts are improvement of  BluSEO plugin https://bit.ly/38Pji2K (Thank you!) */
						
		$html .= '</div>';
		
		return $html;
	}

	public function siteHead()
	{ 
		#fix global names
		global $url;
		global $site;
		global $WHERE_AM_I;
		global $pages;
		global $page;
		$SPACE = '';
		$html =  '';
		
		// Spaces
		if( $this->getValue('space') )
			$SPACE=$this->getValue('space');		
		
		//Default Values
		$og = array
		(
			'lang'		=> $site->language()
		);

		if( $WHERE_AM_I == 'page' )
		{		
			$usr = $page->username() ?? 'admin';			
			$user2 = new User($usr);	 #check if the article has a profile
			$twt   = $user2->twitter() ?? $site->twitter();		# if profile is not available than use sites profile
			
			if(empty($twt)) $twt=$this->getValue('tw_def_page'); #if none exist than use the default plugin
			
			$og['twitteruser']=substr( str_replace('https://twitter.com/','@',$twt) , 0, 16);  #limited chars by login size
			
			$og['type']			= 'article';
			$og['title']		= $page->title() . ' | ' . $site->title();
			$og['description']	= substr( strip_tags( $this->getDescription('fb_description',true) ), 0, 150 ); #FB	
			
			$og['url']			= $page->permalink($absolute=true);			
			$og['image'] 		= $this->getImageURL('fb_defaultImage');
			
			#Twitter
			$og['descriptiontw']	= substr( strip_tags( $this->getDescription('tw_def_desc',true) ), 0, 200 ); #TW
			if(empty($og['descriptiontw'])) $og['descriptiontw']=substr($this->getValue('tw_def_desc'),0,200);
			
			$og['imagetw'] 			= $this->getImageURL('tw_defaultImage');
		}
		elseif( $WHERE_AM_I == 'category' )
		{			
			$og['type']			= 'website';
			$og['title']		= $site->slogan() . ' | ' . $site->title();
			$og['description']	= $this->getDescription('fb_description');
			$og['image']		= $this->getImageURL('fb_defaultImage');
			$og['url']			= $site->url();
			
			# Twitter
			$og['descriptiontw']= $this->getDescription('tw_def_desc');
			$og['imagetw']	    = $this->getImageURL('tw_defaultImage');
		}
		elseif( $WHERE_AM_I == 'tag' )
		{			
			$og['type']			= 'website';
			$og['title']		= $site->slogan() . ' | ' . $site->title();
			$og['description']	= $this->getDescription('fb_description');
			$og['image']		= $this->getImageURL('fb_defaultImage');
			$og['url']			= $site->url();
			
			# Twitter
			$og['imagetw']	    = $this->getImageURL('tw_defaultImage');
			$og['descriptiontw']= $this->getDescription('tw_def_desc');
		}
		else
		{			
			$og['type']			= 'website';
			$og['title']		= $site->slogan() . ' | ' . $site->title();
			$og['description']	= $this->getDescription('fb_description');

				$og['image']		= $this->getImageURL('fb_defaultImage');
				
				$og['imagetw']	    = $this->getImageURL('tw_defaultImage'); # Twitter
  		
			$og['url']			= $site->url();

			# Twitter			
			$og['descriptiontw']= $this->getDescription('tw_def_desc');
		}
		
		if( $this->getValue('fbopenGraphEnabled') && !$url->notFound() )
		{
			$html=PHP_EOL;			
			$html .= $SPACE.'<meta property="og:locale" content="' . $site->locale() . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="og:type" content="' . $og['type'] . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="og:title" content="' . htmlspecialchars( $og['title'], ENT_QUOTES ) . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="og:description" content="' . htmlspecialchars( $og['description'], ENT_QUOTES ) . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="og:url" content="' . $og['url'] . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="og:site_name" content="' . htmlspecialchars( $site->title(), ENT_QUOTES ) . '">' . PHP_EOL;
			
			if (Text::isNotEmpty($this->getValue('fb_AppId')))
				$html .= $SPACE.'<meta property="fb:app_id" content="'. $this->getValue('fb_AppId').'">'.PHP_EOL;
			
			if( $WHERE_AM_I == 'page' )
			{
				$fbp = $user2->facebook() ? $user2->facebook() : $site->facebook();
				
				if($fbp)
					$html .= $SPACE.'<meta property="article:publisher" content="' . $fbp . '">' . PHP_EOL;
				
				else if ( Text::isNotEmpty( $this->getValue('fb_page') ) )
					$html .= $SPACE.'<meta property="article:publisher" content="' . $this->getValue('fb_page') . '">' . PHP_EOL;
				
				$cat = $page->categoryMap(true);
				
				$tags = $page->tags(true);
				
				if ( !empty($tags) )
				{
					foreach($tags as $tagKey=>$tagName)
						$html .= $SPACE.'<meta property="article:tag" content="' . htmlspecialchars( $tagName, ENT_QUOTES ) . '">' . PHP_EOL;
				}
				
				if ( Text::isNotEmpty($cat) )
				{
					$html .= $SPACE.'<meta property="article:section" content="' . ucwords( str_replace( '-', ' ', $cat ) ) . '">' . PHP_EOL;
				}
				
				$html .= $SPACE.'<meta property="article:published_time" content="' . date ('c', strtotime($page->dateRaw())) . '">' . PHP_EOL;
				
				if ( Text::isNotEmpty($page->dateModified()) )
				{
					$html .= $SPACE.'<meta property="article:modified_time" content="' . date ('c', strtotime($page->dateModified())) . '">' . PHP_EOL;
					$html .= $SPACE.'<meta property="og:updated_time" content="' . date ('c', strtotime($page->dateModified())) . '">' . PHP_EOL;
				}						
			}
			#END PAGE
			
			#INI image
			if (!empty($og['image']))
			{				
				$html .= $SPACE.'<meta property="og:image" content="' . $og['image'] . '">' . PHP_EOL;
				
				if ( substr( $og['image'], 0, 8 ) == "https://" )
					$html .= $SPACE.'<meta property="og:image:secure_url" content="' . $og['image'] . '">' . PHP_EOL;
		
				list($img_width, $img_height) = @getimagesize($og['image']);
				
				if ( !empty($img_width) && !empty($img_height) )
				{
					$html .= $SPACE.'<meta property="og:image:width" content="' . $img_width . '">' . PHP_EOL;
					$html .= $SPACE.'<meta property="og:image:height" content="' . $img_height . '">' . PHP_EOL;
				}				
			} 				
			if( !$this->getValue('twcardEnabled') ) $html.=PHP_EOL;
		}
		#END FB
		
		if(!$this->getValue('fbopenGraphEnabled')) $html='';
		
		if( $this->getValue('twcardEnabled') && !$url->notFound() )
		{	
			if(!empty( $og['imagetw'] ) )
			  $html .= PHP_EOL.$SPACE.'<meta property="twitter:card" content="summary_large_image">' . PHP_EOL;			
		    else
			  $html .= $SPACE.'<meta property="twitter:card" content="summary">' . PHP_EOL;			
		
			$html .= $SPACE.'<meta property="twitter:site" content="'.$site->title().'">'.PHP_EOL;			
			
			if(!empty( $og['twitteruser']) ) $html .= $SPACE.'<meta property="twitter:creator" content="'.$og['twitteruser'].'">' . PHP_EOL; #ADDED			
			
			$html .= $SPACE.'<meta property="twitter:description" content="' . htmlspecialchars( $og['descriptiontw'], ENT_QUOTES ) . '">' . PHP_EOL;
			$html .= $SPACE.'<meta property="twitter:title" content="' . htmlspecialchars( substr($og['title'],0,70), ENT_QUOTES ) . '">' . PHP_EOL;   #limited to 70 characters https://bit.ly/36uxEIh		
			
			if(!empty( $og['imagetw'] ) ) $html .= $SPACE.'<meta property="twitter:image" content="' . $og['imagetw'] . '">' . PHP_EOL;
			
			$html.=PHP_EOL;			
		}
		# XML / XTML Tag
		if( $this->getValue('is_xhtml') )
			$html=str_replace('">','" />',$html);
		
		return $html;
	}
		
    public function adminSidebar()
    {     
        return '<li class="nav-item"><a class="nav-link" href="' . HTML_PATH_ADMIN_ROOT . 'configure-plugin/'.get_class($this).'">' .$this->name(). '</a></li>';
    }
	
	# UTILS FUNCTIONS	
	private function OptionDisableEnable($var,$showstatus=true)
	{
		global $L;
		
		$html= '<div class="plgopt">';
		
		if($showstatus) $html.= '<span>'.$L->get('Plugin Status').'</span>';
		
		$html.= '
				<select name="'.$var.'" class="optionplugin">
					 <option value="true" '.($this->getValue($var)===true?'selected':'').'>'.$L->get('Enabled').'</option>
					 <option value="false" '.($this->getValue($var)===false?'selected':'').'>'.$L->get('Disabled').'</option>
				</select>';
				
		$html.= '</div>';
		
		return $html;
	}
	
	// Returns the first image from the page content
	private function getImage($content)
	{
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/ii', $content, $matches);
		
		if (!empty($matches[1][0]))
			return $matches[1][0];

		return false;
	}
	
	// Return the image with fallback
	private function getImageURL($id)
	{
		global $page;
		
		$img='';
		
		if($page)
		{
			$img=$page->coverImage(true);
					
			if(empty($img))
			{				
				$img = $this->getImage($page->content());
			
				if(empty($img))
					$img=$this->getValue($id);
			}			
		}
		else
		{
			$img=$this->getValue($id);
		}
			
		return $img;
	}
	
	// Return the description with fallback
	private	function getDescription($id,$article=false)
	{
		global $site, $page;
		
		if($article) 
		{
			if( Text::isNotEmpty ( $page->description() ) )
				return $page->description();
		}
		
		if( Text::isNotEmpty ( $this->getValue( $id ) ) )
		 return $this->getValue( $id );
		else 
		  return $site->description();			
	}	
	
	/* SITEMAP */	
	private function sitemap_createXML()
	{
		global $site;
		global $pages;

		$xml = '<?xml version="1.0" encoding="UTF-8" ?>';
		$xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

		$xml .= '<url>';
		$xml .= '<loc>'.$site->url().'</loc>';
		$xml .= '</url>';

		$list = $pages->getList($pageNumber=1, $numberOfItems=-1, $published=true, $static=true, $sticky=true, $draft=false, $scheduled=false);
		foreach ($list as $pageKey) {
			try {
				// Create the page object from the page key
				$page = new Page($pageKey);
				if (!$page->noindex()) {
					$xml .= '<url>';
					$xml .= '<loc>'.$page->permalink().'</loc>';
					$xml .= '<lastmod>'.$page->date(SITEMAP_DATE_FORMAT).'</lastmod>';
					$xml .= '</url>';
				}
			} catch (Exception $e) {
				// Continue
			}
		}

		$xml .= '</urlset>';

		// New DOM document
		$doc = new DOMDocument();
		$doc->formatOutput = true;
		$doc->loadXML($xml);
		return $doc->save($this->workspace().'sitemap.xml');
	}

	private function sitemap_ping()
	{
		if ($this->getValue('pingGoogle')) {
			$url = 'https://www.google.com/ping?sitemap='.DOMAIN_BASE.'sitemap.xml';
			TCP::http($url, 'GET', true, 3);
		}

		if ($this->getValue('pingBing')) {
			$url = 'https://www.bing.com/ping?sitemap='.DOMAIN_BASE.'sitemap.xml';
			TCP::http($url, 'GET', true, 3);
		}
	}

	public function install($position=0)
	{
		parent::install($position);
		return $this->sitemap_createXML();
	}

	public function post()
	{
		parent::post();
		
		if($this->getValue('sitemapEnabled'))
		  return $this->sitemap_createXML();
	}

	private function callCreateXMLPING()
	{
		if($this->getValue('sitemapEnabled'))
		{
		  $this->sitemap_createXML();
		  $this->sitemap_ping();
		}
	}
	
	public function afterPageCreate()
	{
		$this->callCreateXMLPING();
	}

	public function afterPageModify()
	{
		$this->callCreateXMLPING();
	}

	public function afterPageDelete()
	{
		$this->callCreateXMLPING();
	}	
}
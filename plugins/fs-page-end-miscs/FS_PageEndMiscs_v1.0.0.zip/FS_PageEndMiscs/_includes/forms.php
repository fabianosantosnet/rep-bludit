<div class="base twocols">

	<h3><?php echo $L->get('page-related-title') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageRelatedEnabled').'</div>' ?></h3>
	<h4><?php echo $L->get('page-related-description'); ?></h4>

<?php	
    $toplink='<p class="toplink"><a href="#top">[top]</a></p>';
    
	$html = '<div>';
	
	$html .= '<label>'.$L->get('page-related-opt-show-title').'</label>';
	$html .= $this->InputTxt('fs_PageRelatedTxtDefaultHeader', $this->getValue('fs_PageRelatedTxtDefaultHeader') , 'inline');
	$html .= '	<span class="tip">'.$L->get('page-related-opt-show-title-tip').'</span><br>';			 
			 
	$html .= '<div>';
	$html .= '	<label>'.$L->get('page-related-opt-list-type-txt').'</label>';	
	$html.= '	<div class="inlineopt sel2">'.$this->Option($this->arPageRelatedTypes,'fs_PageRelatedSelectedType').'</div>';
	$html.= '</div>';			 
	
	
	$html .= '<br>  	<label>'.$L->get('page-related-opt-without-default-html-tags-title').'</label>'.
			 $this->OptionCheckBox('fs_PageRelatedChkRemDefaultsTags', 'inline').'<br>';
	$html .= '	<span class="tip">'.$L->get('page-related-opt-without-default-html-tags-title-tip').'</span>';			 

	$html .= '<br>  	<label>'.$L->get('page-related-chk-sorted').'</label>'.
			 $this->OptionCheckBox('fs_PageRelatedSorted', 'inline');
	
	$html.= $toplink.'</div>';
	
	echo $html;
?>	
</div>


<div class="base twocols">

	<h3><?php echo $L->get('page-child-page-header') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageParentChildEnabled').'</div>' ?></h3>
	<h4><?php echo $L->get('page-child-page-description'); ?></h4>
	
<?php
	$html='';
	$html .= '<div>';
	$html .= '	<label>'.$L->get('page-parent-child-child-lbl-header').'</label> ';
	$html .= $this->InputTxt('fs_PageParentChild_HeaderChild', $this->getValue('fs_PageParentChild_HeaderChild') , 'inline');
	$html .= '	<span class="tip">'.$L->get('page-related-opt-show-title-tip').'</span>'; #let same title because txt is the same
	$html .= '</div><br>';		

	$html .= '<div>';
	$html .= '	<label>'.$L->get('page-parent-child-parent-lbl-header').'</label> ';
	$html .= $this->InputTxt('fs_PageParentChild_HeaderParent', $this->getValue('fs_PageParentChild_HeaderParent') , 'inline');
	$html .= '	<span class="tip">'.$L->get('page-related-opt-show-title-tip').'</span>'; #let same title because txt is the same
	$html .= '</div><br>';			
	
	$html .= '<div><label>'.$L->get('page-related-opt-without-default-html-tags-title').'</label>'.#let same title because txt is the same
			 $this->OptionCheckBox('fs_PageParentChildChkRemDefaultsTags', 'inline').'</div>';

	$html .= '<div><label>'.$L->get('page-parent-child-hide-parent-lbl-title').'</label>'.
			 $this->OptionCheckBox('fs_PageParentChildChkHideParent', 'inline').'</div>';	
             
    $html.= $toplink;
    
	echo $html;
?>		
	
</div>

<div class="base twocols">

	<h3><?php echo $L->get('page-tags-on-page-header') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageTagsEnabled').'</div>' ?></h3>
	<h4><?php echo $L->get('page-tags-on-page-description'); ?></h4>
<?php
	$html = '<div>';
	$html .= '	<label>'.$L->get('page-tags-on-page-lbl-header').'</label> ';
	$html .= $this->InputTxt('fs_PageTagsOnPageHeaderTxt', $this->getValue('fs_PageTagsOnPageHeaderTxt') , 'inline');
	$html .= '	<span class="tip">'.$L->get('page-related-opt-show-title-tip').'</span><br>'; #let same title because txt is the same
	$html .= '</div>';

	$html .= '<div><label>'.$L->get('page-tags-on-page-lbl-show-as-header').'</label>'.#let same title because txt is the same
			 $this->OptionCheckBox('fs_PageTagsOnPageShowAsHeadTxt', 'inline').'</div>';

	$html .= '<div><label>'.$L->get('page-related-opt-without-default-html-tags-title').'</label>'.#let same title because txt is the same
			 $this->OptionCheckBox('fs_PageTagLinkChkRemDefaultsTags', 'inline').'</div>';	
             
    $html.= $toplink;
              
	echo $html;
?>
</div>


<div class="base twocols">

	<h3><?php echo $L->get('page-category-on-page-header') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageCategoryEnabled').'</div>' ?></h3>
	<h4><?php echo $L->get('page-category-on-page-description'); ?></h4>
<?php
	$html = '<div>';
	$html .= '	<label>'.$L->get('page-tags-on-page-lbl-header').'</label> ';
	$html .= $this->InputTxt('fs_PageCategoryOnPageHeaderTxt', $this->getValue('fs_PageCategoryOnPageHeaderTxt') , 'inline');
	$html .= '	<span class="tip">'.$L->get('page-related-opt-show-title-tip').'</span><br>'; #let same title because txt is the same
	$html .= '</div>';

	$html .= '<div><label>'.$L->get('page-tags-on-page-lbl-show-as-header').'</label>'.       #let same title because txt is the same
			 $this->OptionCheckBox('fs_PageCategoryOnPageShowAsHeadTxt', 'inline').'</div>';

	$html .= '<div><label>'.$L->get('page-related-opt-without-default-html-tags-title').'</label>'.#let same title because txt is the same
			 $this->OptionCheckBox('fs_PageCategoryChkRemDefaultsTags', 'inline').'</div>';	
             
    $html.= $toplink;
    
	echo $html;
?>
</div>
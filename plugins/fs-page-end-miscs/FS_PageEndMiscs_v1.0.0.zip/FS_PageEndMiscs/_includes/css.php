<style>					
	form.plugin-form > div:first-of-type > h2 {padding:1rem;background:#f5f5f5;border-bottom:1rem solid #ccc}
	form.plugin-form > div:first-of-type {margin-top:-0.7rem}
	form.plugin-form > div.align-middle > div {padding:1rem}	

	div#plgall {}	
	div#descplg {background:#eee; margin:1rem 0; padding:1rem; border:0.5rem solid #ddd; color:#888;border-left:0;border-right:0}
	
	div#plgall #sharedconfig, div#plgall .base {padding:0 1rem; font-size:0.8rem; background:#f5f5f5}
	div#plgall h3 {padding:1rem 1rem;background:#eee; color:#777; text-transform:uppercase; font-size:1.2rem; font-weight:bold; margin:0 -1rem}
	
	div#plgall h3 .inlineopt {float:right;display:inline-block !important; font-size:1rem;color:#bbb} 
	div#plgall h3 .inlineopt span.msgwarning {text-transform: none;background:#ffe; color:red; padding:0.5rem 1rem}
	
	div#plgall h4 {background-color:#ddd;color:#777;margin:0 -1rem 2rem -1rem; padding:2rem 1rem;font-size:1rem}	
	
	div.plgopt {background:#eee;padding:1rem;text-align:right}
	div.plgopt .optionplugin {width:auto !important;display:inline-block; border-radius:0; height:auto; padding:0.1rem}
	
	div > div.inlineopt {display:inline}
	div > div.inlineopt div.plgopt .optionplugin {display:inline}
	div.inlineopt div.plgopt {width:10rem; padding:0; background:transparent; display:inline}
	
	.base {margin-top:2rem;background-color:#f5f5f5;padding-bottom:2rem !important}
	.base div > label {display:inline-block}
	.base div input.inline {display:inline;border-radius:0;border-color:#ddd;width:69%;padding:2px 6px}

	.twocols label {min-width:300px}
	.twocols .tip {}
    .twocols p.toplink a {float:right;color:#bbb}
    .twocols p.toplink a:hover {color:#777}
	.twocols span.b {display:block; background:#f0f0f0; padding:0.3rem; color:#bbb; line-height:120%; width:100%; cursor:pointer}
	.twocols span.b b {padding:0.1rem 1rem 0.3rem; background-color:#bbb; border-radius:5px; color:#eee; font-size:1rem}
	
	div#plgall .twocols .sel2 select {width:69% !important}
	
	p.copy {background:#eee;padding:1rem;margin:-1rem;border-top:2rem solid #ccc}
	p.copy .tip3 code {font-size:0.7rem;font-family:arial}	
	span.copybased {display:block;font-size:0.7rem;margin-top:1rem;color:#999}
</style>

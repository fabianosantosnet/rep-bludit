<div class="base">
<?php		
		$html='<p class="copy">'.$this->name().' for BLUDIT CMS by @fabianosantosnet. '.$L->get('send-me-tip').'</p>';
		
		echo $html;
?>
</div>
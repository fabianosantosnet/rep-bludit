<div id="descplg"><?php echo $L->get('about-this-plugin-description'); ?></div>

<div id="sharedconfig">

	<h3><?php echo $L->get('shared-config-name'); ?></h3>
	<h4><?php echo $L->get('shared-config-description'); ?></h4>

<?php	
	$html.='<div>';
	$html.= $L->get('shared-config-space-desc');
	$html.='  <input type="button" name="btnSubSpace" id="btnSubSpace" value="-"> ';
	$html.='  <input type="button" name="btnAddSpace" id="btnAddSpace" value="+">';		
	$html.='  <span id="spinfo"><span id="spaceinfo">0</span> '.$L->get('space(s) added').'</span>';    
	$html.='  <input type="hidden" id="space" name="space" value="'.$this->getValue('space').'">';
    $html.='  | <input type="reset" name="btnReset" id="btnReset" value="'.$L->get('Reset').'">';		
	$html.='</div><br>';

	$html .= ' <div>'.
               $L->get('shared-config-lbl-rem-space'). 
               '<div class="inlineopt">'. $this->OptionCheckBox('removeSpaces').'</div>';
	$html.= '  </div><br>';    
    
	$html.='<div>';    
	$html.= $L->get('shared-config-showplglateral-desc');
	$html.= '<div class="inlineopt">'.$this->OptionEnableDisable('showPluginLateralEnabled',false).'</div>';
	$html.= '</div>';
	$html.= '<br>';
	
	echo $html;
?>	
	
</div>
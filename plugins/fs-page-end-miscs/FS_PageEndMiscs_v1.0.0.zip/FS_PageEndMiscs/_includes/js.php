<script>
window.addEventListener('load', (event) => 
{
	function AddSpace()
	{
		var val=parseInt(document.getElementById("spaceinfo").innerHTML);
			val=val+1;
			
			if(val>100) return;
			
		document.getElementById("spaceinfo").innerHTML=val;
		document.getElementById("space").value=document.getElementById("space").value+" ";
	}
	
	function SubSpace()
	{
		var val=parseInt(document.getElementById("spaceinfo").innerHTML);
			val=val-1;
			
			if(val<0) return;
			
		document.getElementById("spaceinfo").innerHTML=val;
		
		sp="";
		for(i=0;i<val;i++) 
			sp+=" ";
		
		document.getElementById("space").value=sp;
	}					

	function ResetCounter()
	{	
		document.getElementById("spaceinfo").innerHTML='0';		
        document.getElementById("space").value='';
	}						
    
	document.getElementById("spaceinfo").innerHTML="<?php echo strlen($this->getValue('space')); ?>";
	document.getElementById("btnAddSpace").onclick=AddSpace;
	document.getElementById("btnSubSpace").onclick=SubSpace;
    document.getElementById("btnReset").onclick=ResetCounter;
});
</script>
				

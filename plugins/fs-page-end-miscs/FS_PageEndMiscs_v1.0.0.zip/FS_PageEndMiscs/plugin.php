<?php
//Plugin by @fabianosantosnet for BLUDT CMS 2021

if(file_exists(PATH_PLUGINS.'_DEBUG.php')) require_once(PATH_PLUGINS.'_DEBUG.php');
require_once('_includes/_helpers.php'); # name of trait changed to avoid broke plugin

class pluginFS_PageEndMiscs extends Plugin 
{
	public function init()
	{
		// Fields and default values for the database of this plugin
		$this->dbFields = array
		(
			'space'=>'',
			'showPluginLateralEnabled'=>true,            
            'removeSpaces'=>false,
			
			'fs_PageRelatedEnabled'=>false,
			'fs_PageRelatedTxtDefaultHeader'=>'Related Pages',
			'fs_PageRelatedChkRemDefaultsTags'=>false,
			'fs_PageRelatedSelectedType'=>'list',
			'fs_PageRelatedSorted'=>true,
			
			'fs_PageParentChildEnabled'=>false,
			'fs_PageParentChild_HeaderChild'=>'Child',
			'fs_PageParentChild_HeaderParent'=>'Parent',
			'fs_PageParentChildChkRemDefaultsTags'=>false,
			'fs_PageParentChildChkHideParent'=>false,
			
			'fs_PageTagsEnabled'=>false,
			'fs_PageTagsOnPageHeaderTxt'=>'Tags',
			'fs_PageTagsOnPageShowAsHeadTxt'=>true,
			'fs_PageTagLinkChkRemDefaultsTags'=>false,
			
			'fs_PageCategoryEnabled'=>false,
			'fs_PageCategoryOnPageHeaderTxt'=>'Category',
			'fs_PageCategoryOnPageShowAsHeadTxt'=>true,
			'fs_PageCategoryChkRemDefaultsTags'=>false			
		);		
		
		$this->arPageRelatedTypes = array
		(
			'0'=>'list',
			'1'=>'link',
			'2'=>'image and title'
		);
	}

	public function form()
	{
		global $L;
		$html='';
		
		include('_includes/css.php');
		include('_includes/js.php');
		
		echo '<div id="plgall">';		
		include('_includes/sharedconfig.php');
		include('_includes/forms.php');		
		include('_includes/footer.php');				
		echo '</div>';
	}
		
    public function adminSidebar()
    {   
		if( $this->getValue('showPluginLateralEnabled') )	
		{
			return '<li class="nav-item"><a class="nav-link" href="' . HTML_PATH_ADMIN_ROOT . 'configure-plugin/'.get_class($this).'">' .$this->name(). '</a></li>';
		}
    }

    public function pageEnd()
    {   
		$html='';
		global $page,$WHERE_AM_I;
        $sp=$this->getValue('space');
		
        
		# START SUBPLUGIN Pages Related		
		if($this->getValue('fs_PageRelatedEnabled') && $WHERE_AM_I==='page')
		{
			$relatedPages = $page->related();
			
			if(@count($relatedPages)>0)
			{				
				$html.= PHP_EOL.$sp.'<div class="fs-page-related">'.PHP_EOL;
				
				# remove html defaults if checked
				if(!$this->getValue('fs_PageRelatedChkRemDefaultsTags')) $html.=$sp.'  <div class="plugin plugin-page-related">'.PHP_EOL;

				# show title only if its not empty
				if(!empty($this->getValue('fs_PageRelatedTxtDefaultHeader')))
					$html.=$sp.'   <h4 class="plugin-label">'.$this->getValue('fs_PageRelatedTxtDefaultHeader').'</h4>'.PHP_EOL;
		
				# remove html defaults if checked
				if(!$this->getValue('fs_PageRelatedChkRemDefaultsTags')) $html.=$sp.'   <div class="plugin-content">'.PHP_EOL;
					
				
				 # row
				$html.=$sp.'      <div class="row">'.PHP_EOL;
				
				# type view as a list
				if($this->getValue('fs_PageRelatedSelectedType')==='list') $html.=$sp."       <ul>".PHP_EOL;			

				
				$sort = array();				

				if($this->getValue('fs_PageRelatedSorted'))
				{						
					foreach ($relatedPages as $pageKey)
					{
						$tmp = new Page($pageKey);
						$sort[$tmp->date('U')] = new Page($pageKey); #// Insert in array by unixtimestamp
					}

					krsort($sort);
					$relatedPages=$sort;
				}				
				
				$i=0;				
				foreach($relatedPages as $pageKey)
				{
					if(!$this->getValue('fs_PageRelatedSorted')) $related = new Page($pageKey);
					else $related=$pageKey;
					
					# type view as a link
					if($this->getValue('fs_PageRelatedSelectedType')==='link')
						$html.=$sp.'        <a href="'.$related->permalink().'">'.$related->title().'</a>'.PHP_EOL;
				
					# type view as a list
					if($this->getValue('fs_PageRelatedSelectedType')==='list')
						$html.=$sp.'        <li class="row"><a href="'.$related->permalink().'">'.$related->title().'</a></li>'.PHP_EOL;					
					
					# type view as a image and title
					if($this->getValue('fs_PageRelatedSelectedType')==='image and title')
					{
						# if logo is set (by control panel) use it, otherwise use default placeholder
						$_THUMB_Related= 'https://via.placeholder.com/200/100/999/ddd/cover.png?text=Dimensions%20Thumb%20Image';		

						$html.=$sp.'        <figure style="max-width:240px" class="col">'.PHP_EOL;			
						$html.=$sp.'          <img src="'.$this->fsGetImageURL($related, $_THUMB_Related).'" />'.PHP_EOL;
						$html.=$sp.'          <figcaption><a href="'.$related->permalink().'">'.$related->title().'</a></figcaption>'.PHP_EOL;
						$html.=$sp.'        </figure>'.PHP_EOL;													
					}
					
					if($i>4) break;  #limited in 6 results 				
					$i++;						
				}			
				
				# type view as a list
				if($this->getValue('fs_PageRelatedSelectedType')==='list') $html.=$sp."       </ul>".PHP_EOL;
				
				$html.=$sp.'      </div>'.PHP_EOL; #end row
				
				# remove html defaults if checked
				if(!$this->getValue('fs_PageRelatedChkRemDefaultsTags')) $html.=$sp.'   </div>'.PHP_EOL; #end content
				if(!$this->getValue('fs_PageRelatedChkRemDefaultsTags')) $html.=$sp.'  </div>'.PHP_EOL; #end plg					
				
				$html.=$sp.'</div>'.PHP_EOL.PHP_EOL;
			}
		}
		# END Plugin Pages Related
			
		
        # START PARENT CHILD
		if($this->getValue('fs_PageParentChildEnabled') && $WHERE_AM_I==='page')  # -- colocar string concatenar pra nao aparecer tag qndo nao tiver
		{
            if($page->hasChildren() || $page->isChild())
            {
                $html.= PHP_EOL.$sp.'<div class="fs-page-parent-child">'.PHP_EOL; #start block
                
                if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'  <div class="plugin plugin-page-parent-child">'.PHP_EOL;
                
                if ($page->hasChildren())
                {
                    $children = $page->children();
                    
                    if(!empty($this->getValue('fs_PageParentChild_HeaderChild'))) $html.=$sp.'    <h4 class="plugin-label">'.$this->getValue('fs_PageParentChild_HeaderChild').'</h4>'.PHP_EOL;
                
                    if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'    <div class="plugin-content">'.PHP_EOL;
                    
                    foreach ($children as $child)				
                        $html.=$sp.'      <a href="'.$child->permalink().'">'.$child->title().'</a><br>'.PHP_EOL;
                    
                    if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'    </div>'.PHP_EOL; #end pgcontent
                }
                
                if(!$this->getValue('fs_PageParentChildChkHideParent'))
                {
                    if($page->isChild())
                    {
                        if ($page->hasChildren()) $html.='<br>';
                        
                        if(!empty($this->getValue('fs_PageParentChild_HeaderParent'))) $html.=$sp.'    <h4 class="plugin-label">'.$this->getValue('fs_PageParentChild_HeaderParent').'</h4>'.PHP_EOL;
                        
                        if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'    <div class="plugin-content">'.PHP_EOL;
                        
                        $html.=$sp.'      <a href="'.$page->parentMethod('permalink').'">'.$page->parentMethod('title').'</a><br>'.PHP_EOL;
                        
                        if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'  </div>'.PHP_EOL;
                    }		
                }
                
                if(!$this->getValue('fs_PageParentChildChkRemDefaultsTags')) $html.=$sp.'  </div>'.PHP_EOL; # end plugin default			
                
                $html.=$sp.'</div>'.PHP_EOL; #end block			
            }  
        }        
        # END PARENT CHILD
		
        # START TAG LINK
		if($this->getValue('fs_PageTagsEnabled') && $WHERE_AM_I==='page')
		{	
			$items = $page->tags(true);
			if(count($items)>0)
			{
				$links='';
				
				$i=0;
				foreach ($items as $tagKey=>$tagName)
				{
					$tag = new Tag($tagKey);
					$links.=$sp.'      <a href="'.$tag->permalink().'">'.$tag->name().'</a> '.PHP_EOL;
					
					if($i>3) break;  #limited in 5 results 				
					$i++;
				}        
							
				$html.= PHP_EOL.$sp.'<div class="fs-taglink">'.PHP_EOL;	#start block	
				
				if(!$this->getValue('fs_PageTagLinkChkRemDefaultsTags')) $html.=$sp.'  <div class="plugin plugin-page-tag-link">'.PHP_EOL; # ini plugin
							
				if($this->getValue('fs_PageTagsOnPageHeaderTxt'))
				{
					if(!empty($this->getValue('fs_PageTagsOnPageHeaderTxt')))
					{
						if($this->getValue('fs_PageTagsOnPageShowAsHeadTxt'))				
							$html.=$sp.'    <h4 class="plugin-label">'.$this->getValue('fs_PageTagsOnPageHeaderTxt').'</h4>'.PHP_EOL;
						
						else 
							$html.=$sp.'    '.$this->getValue('fs_PageTagsOnPageHeaderTxt').': '.PHP_EOL;			
					}
				}
				
				if(!$this->getValue('fs_PageTagLinkChkRemDefaultsTags')) $html.=$sp.'    <div class="plugin-content">'.PHP_EOL; #ini content
				
				$html.=$links;
				
				if(!$this->getValue('fs_PageTagLinkChkRemDefaultsTags')) $html.=$sp.'    </div>'.PHP_EOL;#end content
				if(!$this->getValue('fs_PageTagLinkChkRemDefaultsTags')) $html.=$sp.'  </div>'.PHP_EOL;#end plugin
							
				$html.=$sp.'</div>'.PHP_EOL; #end block
			}
		}
        # END TAG LINK
		
        # START CATEGORY LINK
		if($this->getValue('fs_PageCategoryEnabled') && $WHERE_AM_I==='page')
		{				
			if(!empty($page->category()))
			{				
				$html.= PHP_EOL.$sp.'<div class="fs-categorylink">'.PHP_EOL; # start block
				
				try
				{	
					# $page->category() contains only name - and it can be changed and could be different from url
					# which cause error of get category using name instead key, in this case need validation...
					# but if you have two categories with same name, it will return the first one (the URL could not be what you expect)
		
					$items = getCategories();

					# remove html defaults if checked
					if(!$this->getValue('fs_PageCategoryChkRemDefaultsTags')) $html.=$sp.'  <div class="plugin plugin-page-category-link">'.PHP_EOL; #ini plugin
					
					foreach ($items as $category)
					{
						if( strtolower($category->name()) === strtolower($page->category()) )
						{
							if(!empty($this->getValue('fs_PageTagsOnPageHeaderTxt')))
							{														
								if($this->getValue('fs_PageCategoryOnPageShowAsHeadTxt'))
									$html.= $sp.'    <h4 class="plugin-label">'.$this->getValue('fs_PageCategoryOnPageHeaderTxt').'</h4>'.PHP_EOL;
								else 
									$html.= $sp.'    '.$this->getValue('fs_PageCategoryOnPageHeaderTxt').': '.PHP_EOL;
							}

							if(!$this->getValue('fs_PageCategoryChkRemDefaultsTags')) $html.=$sp.'    <div class="plugin-content">'.PHP_EOL; #ini content	
							
							$html.= $sp.'      <a href="'.$category->permalink().'">'.$page->category().'</a>'.PHP_EOL;
							
							if(!$this->getValue('fs_PageCategoryChkRemDefaultsTags')) $html.=$sp.'    </div>'.PHP_EOL;#end content
							
							if(!$this->getValue('fs_PageCategoryChkRemDefaultsTags')) $html.=$sp.'  </div>'.PHP_EOL;#end plugin
							
							break; # bludit allow only one category by post
						}
					}													

				}
				catch(Exception $ex)
				{	
					$html.='Plugin Error: Something was wrong with'.$this->name().' Plugin.';
				}
				
				
				$html.= $sp.'</div>'.PHP_EOL; #end block
			}
		}
        # END CATEGORY LINK
		
		#$html=$this->indentContent($html);
        
		if( $this->getValue('removeSpaces') )        
            $html=trim(preg_replace('/\s+/', ' ', $html));
        
		return $html;
    }
	
	public function install($position=0)
	{
		parent::install($position);		
	}

	public function post()
	{
		parent::post();
	}

	public function afterPageCreate()
	{
		parent::post();
	}

	public function afterPageModify()
	{
		parent::post();
	}

	public function afterPageDelete()
	{
		parent::post();
	}				
	
	# include utils functions by trait on includes
	use FS_Utils_PageEndMiscs;
}
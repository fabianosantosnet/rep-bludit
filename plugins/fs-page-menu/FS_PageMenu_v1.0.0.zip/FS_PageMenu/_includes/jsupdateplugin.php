<script>
window.addEventListener('load', (event) => 
{ 
    if (window.fetch) 
    {
        var request = new Request('https://git.fabianosantos.net/checkLastedVersion.json.php', 
        {
            method: 'GET',
            headers: new Headers({'Content-Type':'text/json'}),
            cache: "force-cache"
        });        
        
        fetch(request)
        .then
        (
            function(response)
            {
                if(response.ok)
                   return response.json();
                
                else
                    return Promise.reject(response);
            }
        )
        .then
         (
            function (data)
            {
                var $vPlgUpdated=data.bludit.plugins["<?php echo $jsonNamePlugin ?>"];
                
                if(!$vPlgUpdated) $vPlgUpdated=".";
                
                $vPlgUpdated=$vPlgUpdated.replaceAll(".","");
                
                if($vPlgUpdated > <?php echo str_replace('.','',$pluginBluditVersionInstalled)  ?>)
                {   
                    if(window.location.href=='<?php echo DOMAIN_BASE.'admin/configure-plugin/'.$this->className()?>')
                    {   
                        document.getElementById('linknewversion').innerText="<?php echo $L->get('fs-plugin-link-text-update')?>";
                        document.getElementById('linknewversion').className="update";
                        document.getElementById('linknewversion').setAttribute('href',"<?php echo $this->website()?>");
                    }                    
                    
                    document.getElementById('link-update-plg-<?php echo str_replace(" ","-",strtolower($this->name()));?>').innerHTML+=' <span title="Update to new version ! / Nova versão disponível"> ! </span>';
                    document.getElementById('link-update-plg-<?php echo str_replace(" ","-",strtolower($this->name()));?>').children[0].style="padding:0.1rem;color:red;background:#ffb";
                    console.log("BLUDIT CMS - PLUGIN <?php echo $this->name().' - '.$L->get('fs-plugin-link-text-update')?>");
                }
            }
         )
         .catch
         (
            function (err)
            {
                console.warn('Something went wrong when trying to get information about Bludit Plugin "<?php echo $this->name()?>".', err);
            }
        );
    }
});
</script>
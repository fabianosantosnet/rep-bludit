form.plugin-form > div:first-of-type > h2 {padding:1rem;background:#eee;color:#444;border-bottom:1rem solid #777;text-transform: uppercase}
form.plugin-form > div:first-of-type {margin-top:-0.7rem}
form.plugin-form > div.align-middle > div {padding:1rem}	

div#plgall {background:#fff}	

div#descplg {background:#eee; margin:1rem 0 1rem 0; padding:1rem;border:0rem solid #777; color:#777;border-left:0;border-right:0}
div#descplg h2 {background-color:#777;padding:1rem;margin:0 -1rem 0 -1rem;color:#eee;text-transform:uppercase;font-size:1.6rem;font-weight:bold}
div#descplg h2 span,div#sharedconfig h3 span {float:right;background:#aaa;padding:0 0.4rem 0.2rem 0.4rem;cursor:pointer;border-radius:5px}
div#descplg section, div#sharedconfig section {display:none}

div#descplg ul.plg {list-style:none;padding:0 0.5rem}
div#descplg ul.plg li span.t {background:#ddd;color:#444;padding:0.4rem;margin:0;width:7rem;display:inline-block;margin-left:-8.2rem;margin-right:1rem}
div#descplg hr {margin:2rem 0;padding:0;display:block;border-color:#ddd}
div#descplg ul.plg li {padding:0.1rem 1rem;margin:0 0 1rem 7.7rem;border:1px solid #ccc;background:#dfdfdf}
div#descplg ul.plg li span.t s {display:none}
div#descplg div.info {float:right;margin:1rem 0rem 0 2rem}  
div#descplg div.info a {color:#777;display:block;background-color:#fff;padding:0.5rem;margin:0.2rem 0;font-size:0.8rem;box-shadow:1px 1px 1px}
div#descplg div.info a:hover {background-color:#ffe}

div#plgall div.info a.nod {display:none}
div#plgall #descplg p {max-width:70%}
div#plgall div.info a.update,
div#plgall #descplg span.right {display:block;margin-top:0.1rem;color:red;background:#ffe;padding:0.2rem;font-weight:bold}

div#plgall #descplg span.right {float:right;margin-top:-12rem;margin-left:4rem;font-size:0.8rem;background:#ddd;text-align:center;color:#777;z-index:1000;position:relative}
div#plgall #descplg span.right b {display:block;font-weight:normal;color:#777;padding:0.5rem;text-shadow:1px 1px 1px #fff;text-transform:uppercase}
div#plgall #descplg span.right a {font-weight:normal;color:#777;background-color:#fff;padding:0.5rem;display:block;margin:0.2rem -0.1rem 0.1rem -0.1rem;box-shadow:1px 1px 1px}
div#plgall #descplg span.right a:hover {background-color:#ffe}

div#plgall #sharedconfig, div#plgall .base {padding:0 1rem; font-size:0.8rem; background-color:#f5f5f5}
div#plgall h3 {padding:1rem 1rem;background-color:#eee; color:#777; text-transform:uppercase; font-size:1.2rem; font-weight:bold; margin:0 -1rem}

div#plgall h3 .inlineopt {float:right;display:inline-block !important; font-size:1rem;color:#bbb} 
div#plgall h3 .inlineopt span.msgwarning {text-transform:none;background:#ffe; color:red; padding:0.5rem 1rem}
div#plgall h4 {background-color:#ddd;color:#777;margin:0 -1rem 2rem -1rem; padding:2rem 1rem;font-size:1rem}	

div#sharedconfig {padding-bottom:2rem !important;background:#eee !important}
div#sharedconfig h3 {background-color:#777;color:#ddd}
div#sharedconfig h4 {}
div#sharedconfig  div {color:#777;font-size:1rem}
div#sharedconfig  div input[id=btnSaveConfig] {width:100px}
div#sharedconfig  div.decor {margin-top:-1rem}
div#sharedconfig  div > div.space {display:inline-block;margin-left:1rem;margin-top:-2rem}
div#sharedconfig  div select {margin-right:1rem;min-width:90px}
div#sharedconfig  div input {min-width:20px;margin-bottom:1px;border-radius:0;border:1px double #ccc;color:#555}
div#sharedconfig  div input:first-of-type {margin-top:-1rem;}
div#sharedconfig  div .tip {background-color:#f5f5f5;display:inline-block;padding:0.4rem}
div#sharedconfig #switchplugin ul {width:99.7%;height:auto;margin:0;padding:1rem;overflow:hidden;scrollbar-width:none;border:1px solid #ddd; border-radius:0;background-color:#fff;list-style:none}
div#sharedconfig #switchplugin ul li {background-color:#eee;border-top:1px solid #fff;color:#777;;margin-bottom:2px;padding:0.3rem;cursor:pointer;font-size:0.8rem}
div#sharedconfig #switchplugin ul li::before {content:'\21c5 ';margin-right:1rem}
div#sharedconfig #switchplugin ul li:hover {background-color:#777 !important;color:#fff}

div.plgopt {background:#eee;padding:1rem;text-align:right}
div.plgopt .optionplugin {width:auto !important;display:inline-block; border-radius:0; height:auto; padding:0.1rem}

div > div.inlineopt {display:inline}
div > div.inlineopt div.plgopt .optionplugin {display:inline}
div.inlineopt div.plgopt {width:10rem; padding:0; background:transparent; display:inline}

.twocols label {min-width:300px}
.twocols .tip {}
.twocols p.toplink a {float:right;color:#bbb}
.twocols p.toplink a:hover {color:#777}
.twocols span.b {display:block; background:#f0f0f0; padding:0.3rem; color:#bbb; line-height:120%; width:100%; cursor:pointer}
.twocols span.b b {padding:0.1rem 1rem 0.3rem; background-color:#bbb; border-radius:5px; color:#eee; font-size:1rem}

div#plgall .twocols .sel2 select {width:69% !important}

div#plgall div.base nav {background:#777;margin:-0.5rem -1rem 0.1rem -1rem;padding:2rem 0.5rem;box-shadow:1px 1px 1px #bbb}
div#plgall div.base nav a {background-color:#ddd;padding:1rem;display:inline-block;color:#777;text-transform:uppercase;border:1px solid #bbb;border-bottom:0;margin-top:0;font-size:0.9rem;font-weight:bold;letter-spacing:1px}
div#plgall div.base nav a:hover {background-color:#eee;color:#555}
div#plgall div.base nav a span {background:#ccc;margin-left:0.4rem;display:inline-block;padding:0 0.3rem}
div#plgall div.base nav a.active-menu {background-color:#777;color:#eee}
div#plgall div.base nav a.active-menu span {background-color:#999;color:#444}

div#plgall div.twocols[id*="subplg"] {display:none}
div#plgall div.twocols[id="subplg01"] {display:block}

div#plgall div.twocols h3 {background-color:#777;color:transparent}
div#plgall div.twocols h4 {background-color:#ddd}
div#plgall div.twocols .msgwarning {display:block;padding:0.5rem;background-color:#ffe;color:red;font-size:0.8rem;text-align:center;margin:2rem 0;font-weight:bold}
div#plgall div.twocols .block {color:#777;font-size:0.8rem;clear:both}
div#plgall div.twocols .block label {display:block;width:auto;max-width:30%;min-width:30%;float:left;position:relative;top:0;text-align:right;padding-right:1rem}
div#plgall div.twocols .block input,
div#plgall div.twocols .block select {width:69%;display:inline-block;margin:0;border:1px double #ddd; border-radius:0 !important;color:#777}
div#plgall div.twocols .block span.tip {background-color:#eee;display:inline-block;width:69%;padding:0.3rem;margin-bottom:1rem;font-size:0.8rem}
div#plgall div.twocols .block span.tip a {color:#777;text-decoration:underline}
div#plgall div.twocols .block span.left {display:block;width:30%;text-align:right}
div#plgall div.twocols .block span.right-top {display:inline-block;width:25%}

div#plgall div.twocols .block .plgopt {background:transparent;margin-left:30%;margin-right:0.4rem;padding:0}
div#plgall div.twocols .block .plgopt .optionplugin {min-width:100%;font-size:1rem;padding:0.5rem}
div#plgall div.twocols .block .grp {width:70%;margin-left:30%;padding:1rem 0}
div#plgall div.twocols .block .grp-less2 {margin-top:-1.2rem !important}

div#plgall div.twocols .block .grp * {display:inline;padding:0;margin:0;width:auto;min-width:auto;max-width:auto}
div#plgall div.twocols .block .grp span {display:inline-block;padding:0 1rem}
div#plgall div.twocols .block .less {margin:-0.5rem 0 !important}

div#plgall div.twocols .block .only {margin:0.5rem 0 0 0;}
div#plgall div.twocols .block .only label {min-width:41%;display:block;margin-top:0rem !important;}
div#plgall div.twocols .block .only input[type=checkbox] {margin-left:1.3rem}

div#plgall div.twocols .block .only > div {width:100%;display:block;margin:1.4rem 0}
div#plgall div.twocols .block .only > div label.right {text-align:right}

div#plgall div.twocols .block input[type=text].min {width:50px}
div#plgall div.twocols .block input[type=number].min {width:50px;min-height:2.2rem}
div#plgall div.twocols .block input[type="button"], div#plgall div.twocols .block input[type="submit"] {box-shadow:1px 1px 1px;display:block !important;}

div#plgall div.twocols .block input[type="button"]:active, div#plgall div.twocols .block input[type="submit"]:active {box-shadow:1px 1px 1px #fff !important;}

div#plgall div.twocols .block input[id=fs_PageMenu_LinksBtnAdd],
div#plgall div.twocols .block input[id=fs_PageMenu_LinksBtnRemove]
{width:18% !important;margin:4rem 0 -3rem 10% !important;display:block}

div#plgall div.twocols .block input[id*=btnSave] {margin:0rem 0 1rem 30%;width:69%}

div#plgall div.twocols .block ul[id=fs_PageMenu_LinksMultiple_LIST] {margin:-7rem 0 1rem 30%;width:69%;border:1px solid #ddd;padding:1rem;min-height:150px;max-height:300px;overflow-y:scroll;list-style:none;background:#fff}
div#plgall div.twocols .block ul[id=fs_PageMenu_LinksMultiple_LIST] li:active {background-color:#000 !important;}
.placeholderClass {border:1px solid #ddd;background:#ddd;color:#ffb}
.hoverClass {background:#777 !important;color:#fff}

div#plgall div.twocols .block ul[id=fs_PageMenu_LinksMultiple_LIST] li {background:#eee;margin-bottom:2px;padding:0.3rem;cursor:pointer}
div#plgall div.twocols .block ul[id=fs_PageMenu_LinksMultiple_LIST] li::before {content:'\21c5 ';margin-right:1rem}
div#plgall div.twocols .block input[id=fs_PageMenu_LinksBtnAdd] {width:14%;margin:2rem 0 0rem 15%;display:block}
            
div#plgall div.twocols .block .grp-vert {}
div#plgall div.twocols .block .grp-vert span {display:block;padding:0.5rem 1rem}
div#plgall div.twocols .block .grp-vert span input {margin-right:1rem}

div#plgall div.twocols .bwide {}
div#plgall div.twocols .bwide label,
div#plgall div.twocols .bwide .tip {width:auto;margin:0;min-width:100%;padding:1rem;background:#eee;margin-bottom:0.3rem}
div#plgall div.twocols .bwide .tip {margin-top:0.1rem}
div#plgall div.twocols .bwide textarea {border:1px solid #ddd;border-radius:0}

div#plgall div.twocols .header,div#plgall div.twocols .header-right {padding:1rem;color:#777;background-color:#fff;font-size:0.94rem;margin:0.3rem 0.5rem 0.3rem 0}
div#plgall div.twocols .header-right {max-width:70%;margin-left:30%}

div#plgall div.twocols p.toplink {margin:0;padding:1rem 0.5rem 2.4rem 0rem}


p.warning {background-color:#ffb;color:red;font-weight:bold;border:0.3rem solid #fff;padding:0.5rem;min-width:100%}
p.warning span {text-transform:uppercase}


.btnUninstallPlugin {float:right;margin-top:-2rem;color:#777}
p.copy {background:#eee;padding:2rem 1rem;margin:1rem -1rem 0 -1rem;border-top:2rem solid #777;color:#555}
p.copy .tip3 code {font-size:0.7rem;font-family:arial}	
span.copybased {display:block;font-size:0.7rem;margin-top:1rem;color:#999}


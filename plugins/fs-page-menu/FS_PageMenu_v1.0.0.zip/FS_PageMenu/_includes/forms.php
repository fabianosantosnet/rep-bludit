<?php	
    $toplink='<p class="toplink"><a href="#top">[top]</a></p>';

    $nameSUBPLUGIN='';
    $nameSUBPLUGIN0='links';
    $nameSUBPLUGIN1='navigation';
    $nameSUBPLUGIN2='static';

        
    $html = '<div class="base">';
    
    $html .= '
    <a name="menu"></a>
    <nav id="plgfsmenu">
        <a href="#menu" id="subplg01_">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-link-text') . '<span> - </span></a>
        <a href="#menu" id="subplg02_">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-link-text') . '<span> + </span></a>
        <a href="#menu" id="subplg03_">'.$L->get($NPLG.'-'.$nameSUBPLUGIN2.'-link-text') . '<span> + </span></a>
    </nav>    
    ';
    
    $html .= '</div>';
    
    $html .= '<div class="base twocols" id="subplg01">
              <h3>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-title') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageMenu_LinksEnabled',false).'</div></h3>
              <h4>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-description').'</h4>';

        if(pluginActivated('pluginLinks'))
		  $html.= '<span class="msgwarning">'.$L->get('plg-links-already-running').'</span>';
    
    $html .= '<div class="block">';
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-lbl-header-title').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_LinksHeaderTitle', $this->getValue('fs_PageMenu_LinksHeaderTitle') , 'class').PHP_EOL;    
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-header-title-tip').'</span>'.PHP_EOL;        
    
	$html .= '	<label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN.'links-lbl-location').'</label>';	
	$html.= 	$this->OptionLocation('fs_PageMenuLinksLocationSelected',false);
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-location-tip').'</span>'.PHP_EOL;    
    
    $html .= ' <div class="grp only less">';
    $html .= '	<label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN.'chk-lbl-rem-defaults');	
    $html .= '	</label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenuLinksChkRemDefaultsTags', '');    
    $html .= ' </div>';
    
    $html .= '</div>';#end block
    
    $html .= '<hr><br>';
    $html .= '<div class="block">';
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-lbl-link-name').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_LinksTextLink', $this->getValue('fs_PageMenu_LinksTextLink') , 'class').PHP_EOL;    
    $html .= '</div>';#end block
    
    $html .= '<div class="block">';
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-lbl-link-url').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_LinksURL', $this->getValue('fs_PageMenu_LinksURL') , 'class').PHP_EOL;    
$html .= '<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-select-tip').'</span>'.PHP_EOL;        
    $html .= '</div>';#end block    
    
    $html .= '<div class="block">';

    $html .= '  <input type="button" name="fs_PageMenu_LinksBtnAdd" id="fs_PageMenu_LinksBtnAdd" value="'.$L->get('fs-page-menu-links-btn-add').'" />';
    
    $html .= '  <input type="button" name="fs_PageMenu_LinksBtnRemove" id="fs_PageMenu_LinksBtnRemove" value="'.$L->get('fs-page-menu-links-btn-remove').'" />';
    
    $arLinks=json_decode( $this->getValue('fs_PageMenu_LinksMultiple',false),true);
    
    $html .= '  <ul id="fs_PageMenu_LinksMultiple_LIST">'.PHP_EOL;
    
    if(count($arLinks)>0)
    {
        foreach($arLinks as $indice=>$string)
        {
          list($link,$name)=explode(SEPARATORFS,$string);          
          $html .= '<li data-link="'.$link.'">'.$name.'</li>'.PHP_EOL;
        }
    }
    
    $html .= '  </ul>'.PHP_EOL;    

    $html .= '<input type="button" name="btnSaveLinks" id="btnSaveLinks" value="'.$L->get('Save').'">';
    $html .= '<input type="hidden" name="selectedItem" id="selectedItem" value="last">';
    
    $html .= '</div>';#end block       
    
    $html.= $toplink;    
    
    $html.= '</div>';#END LINKS
    
    
    # START NAVIGATION
    $html .= '<div class="base twocols" id="subplg02">
              <h3>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-title') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageMenu_NavigationEnabled',false).'</div></h3>
              <h4>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-description').'</h4>';

        if(pluginActivated('pluginNavigation'))
		  $html.= '<span class="msgwarning">'.$L->get('plg-navigation-already-running').'</span>';
             
    $html .= '<div class="block">';
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-header-title').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_NavigationHeaderTitle', $this->getValue('fs_PageMenu_NavigationHeaderTitle') , 'class').PHP_EOL;    
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-header-title-tip').'</span>'.PHP_EOL;        
    
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-rem-pages').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_NavigationRemPages', $this->getValue('fs_PageMenu_NavigationRemPages')).PHP_EOL;
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-rem-pages-tip').'</span>'.PHP_EOL;
        
	$html .= '	<label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-lbl-location').'</label>';	
	$html.= 	$this->OptionLocation('fs_PageMenuNavigationLocationSelected',false);
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-location-tip').'</span>'.PHP_EOL; 
    
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-count-limit').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_NavigationCountLimit', $this->getValue('fs_PageMenu_NavigationCountLimit') , 'min','number').PHP_EOL; #<== HTML5 type number
    $html .= '	<span class="tip right-top1">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-count-limit-tip').'</span>'.PHP_EOL;
    
    $html .= ' <div class="grp grp-less2 only">';
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN1.'-chk-lbl-add-home-link');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenuNavigationChkAddHomeLink', '');
    $html .= '  </div>';
    
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN.'chk-lbl-rem-defaults');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenuNavigationChkRemDefaultsTags', '');    
    $html .= '  </div>';
    
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN.'chk-lbl-child-pages');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenuNavigationChkChildPages', '');    
    $html .= '  </div>';    
    $html .= ' </div>';
    
    $html .= '<input type="submit" name="btnSaveNavigation" id="btnSaveNavigation" value="'.$L->get('Save').'" />';
    
    $html .= '</div>';#end block
    $html.= $toplink;    
    $html.= '</div>';
    # END NAVIGATION


    # INI STATIC MENU -----------------------------------
    $html .= '<div class="base twocols" id="subplg03">
              <h3>'.$L->get($NPLG.'-'.$nameSUBPLUGIN2.'-title') . '<div class="inlineopt">'.$this->OptionEnableDisable('fs_PageMenu_StaticEnabled',false).'</div></h3>
              <h4>'.$L->get($NPLG.'-'.$nameSUBPLUGIN2.'-description').'</h4>';

        if(pluginActivated('pluginStaticPages'))
		  $html.= '<span class="msgwarning">'.$L->get('plg-static-already-running').'</span>';
      
    $html .= ' <div class="block">';#start block
    
    $html .= '   <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-header-title').'</label>'.PHP_EOL; 
    $html .=      $this->InputTxt('fs_PageMenu_StaticHeaderTitle', $this->getValue('fs_PageMenu_StaticHeaderTitle') , 'class').PHP_EOL;    
    $html .= '	  <span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-header-title-tip').'</span>'.PHP_EOL;              
    
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-rem-pages').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_StaticRemPages', $this->getValue('fs_PageMenu_StaticRemPages')).PHP_EOL;
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-rem-pages-tip').'</span>'.PHP_EOL;
    
    $html .= '	<label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-lbl-location').'</label>';	
	$html.= 	$this->OptionLocation('fs_PageMenu_StaticLocationSelected',false);
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN0.'-location-tip').'</span>'.PHP_EOL; 
    
    $html .= '  <label>'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-lbl-count-limit').'</label>'.PHP_EOL; 
    $html .=    $this->InputTxt('fs_PageMenu_StaticCountLimit', $this->getValue('fs_PageMenu_StaticCountLimit') , 'min','number').PHP_EOL; #<== HTML5 type number
    $html .= '	<span class="tip">'.$L->get($NPLG.'-'.$nameSUBPLUGIN1.'-count-limit-tip').'</span>'.PHP_EOL;
    
    #
    $html .= ' <div class="grp grp-less2 only">';
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN1.'-chk-lbl-add-home-link');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenu_StaticChkAddHomeLink', '');
    $html .= '  </div>';
    
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN.'chk-lbl-rem-defaults');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenu_StaticChkRemDefaultsTags', '');    
    $html .= '  </div>';
    
    $html .= '  <div>';
    $html .= '	 <label>';
    $html .=        $L->get($NPLG.'-'.$nameSUBPLUGIN.'chk-lbl-child-pages');	
    $html .= '	 </label>';    
    $html .=     $this->OptionCheckBox('fs_PageMenu_StaticChkChildPages', '');    
    $html .= '  </div>';    
    $html .= ' </div>';
    #
        
    $html .= '<input type="submit" name="btnSaveStatic" id="btnSaveStatic" value="'.$L->get('Save').'" />';
    $html .= ' </div>';#end block    
    $html.= $toplink;    
    $html.= '</div>';
    # END STATIC MENU -----------------------------------
    
    echo $html;
    
?>	
    
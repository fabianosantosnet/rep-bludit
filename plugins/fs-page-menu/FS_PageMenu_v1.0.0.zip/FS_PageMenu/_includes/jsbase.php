<script>
window.addEventListener('load', (event) => 
{ 
    // INI SHOW HIDE INFO
    function ShowHideSection(btn, $el)
    {
        if($el.style.display=='none')
        {
            $el.style.display='block';
            btn.innerText=' - ';
        }
        else
        {
            <?php if($this->getValue('hideEntryHTMLBlocks')==false) { 
            
            ?> if($el.style.display!=='none' && $el.style.display!=='block')
            {
                //initialize show
                $el.style.display='block';
                btn.innerText=' - '; 
            }
            else
            {
                $el.style.display='none';
                btn.innerText='+';
            }<?php }
            else
            {?>$el.style.display='none';
                btn.innerText='+';<?php }?>
                
        }		
    }
        
    $btn=document.querySelectorAll("span.showData");
    $element=document.getElementsByTagName("section");            

    ShowHideSection($btn[0], $element[0]);
    
    $btn[0].onclick=function()
    {
        ShowHideSection(this, $element[0]);
    }
    
    ShowHideSection($btn[1], $element[1]);
    
    $btn[1].onclick=function()
    {
        ShowHideSection(this, $element[1]);
    }    
    
    
    // # INI DISPLAY-HIDEN MENU
    function ShowHideLink(links,btn)
    {
        id=btn.id.replaceAll('_','');
        $el=document.getElementById(id);
        
        nid=(parseInt(id.replaceAll('subplg0',''))-1);
        
        if(links[nid].id==btn.id)
        {
            if($el.style.display=='none')
            {
                $el.style.display='block';
                
                btn.children[0].innerText='-';
                btn.className="active-menu";

                for(i=0;i<links.length;i++)
                {
                    if(links[i].id!==btn.id)
                    {
                        $m=document.getElementById(links[i].id.replaceAll('_',''));             
                        $m.style.display='none';          
                        
                        links[i].children[0].innerText='+';
                        links[i].classList.remove("active-menu");
                    }
                    else
                    {
                        links[i].children[0].innerText='-';
                    }
                }    
            }
            else //display block
            {
                $el.style.display='none';
                btn.children[0].innerText='-';

                for(i=links.length;i>links.length;i--)
                {
                    if(links[i].id!==btn.id)
                    {
                        $m=document.getElementById(links[i].id.replaceAll('_',''));
                        $m.style.display='none';
                        links[i].children[0].innerText='+';
                    }
                    else
                    {
                        $m=document.getElementById(links[i].id.replaceAll('_',''));
                        $m.style.display='none';
                        links[i].children[0].innerText='+';
                    }
                }                    
            }       
        } 
    }  
    
    $links=document.querySelectorAll("nav#plgfsmenu a");
        
    $links[0].onclick=function()
    {
        ShowHideLink($links,this);
    }    
        
    $links[1].onclick=function()
    {
        ShowHideLink($links,this);
    }       

    $links[2].onclick=function()
    {
        ShowHideLink($links,this);
    }    
    
    for(f=0;f<$links.length;f++)
    {
        ShowHideLink($links,$links[f]);
        $links[f].children[0].innerText="+";
        
        if(f==<?php echo $ActiveTabDefault ?>)
        {
            $links[f].children[0].innerText="-";
            id=$links[f].id.replaceAll('_','');
            $el=document.getElementById(id);
            $el.style.display='block';            
            $links[f].className="active-menu"
        }
    }
      // # END INITIALIZE DISPLAY-HIDEN
    
    // END SHOW HIDE INFO
    
    function AddSpace()
    {
        var val=parseInt(document.getElementById("spaceinfo").innerHTML);
            val=val+1;
            
            if(val>100) return;
        
        document.getElementById("spaceinfo").innerHTML=val;
        document.getElementById("space").value=document.getElementById("space").value+" ";
    }
    
    function SubSpace()
    {
        var val=parseInt(document.getElementById("spaceinfo").innerHTML);
            val=val-1;
            
            if(val<0) return;
            
        document.getElementById("spaceinfo").innerHTML=val;
        
        sp="";
        for(i=0;i<val;i++) 
            sp+=" ";
        
        document.getElementById("space").value=sp;
    }					

    function ResetCounter()
    {	
        document.getElementById("spaceinfo").innerHTML='0';		
        document.getElementById("space").value='';
    }						
    
    function ConfirmUninstallPlugin()
    {	
        if(confirm("<?php echo $L->get('fs-click-to-unistall-plugin') ?>"))
            return true;
        else
            return false
    }    
    
    document.getElementById("spaceinfo").innerHTML="<?php echo strlen($this->getValue('space')); ?>";
    document.getElementById("btnAddSpace").onclick=AddSpace;
    document.getElementById("btnSubSpace").onclick=SubSpace;
    document.getElementById("btnReset").onclick=ResetCounter;
    document.getElementById("btnUninstallPlugin").onclick=ConfirmUninstallPlugin;
    
   
   sortable('#OrderSubPlugins_LIST', 
    {
        forcePlaceholderSize: true,
        placeholderClass: 'placeholderClass',
        hoverClass: 'hoverClass'
    });
     
    
    document.getElementById('btnSaveConfig').onclick=function()
    {   
         var select = document.createElement("select");
             select.name = "OrderSubPlugins[]";
             select.id = "OrderSubPlugins";
             select.setAttribute('multiple','multiple');
             
            data = document.getElementById('OrderSubPlugins_LIST').getElementsByTagName('li');
        
        for (const val of data)
        {
            var option = document.createElement("option");
            option.value = val.getAttribute('data-order');
            select.appendChild(option);
        }
        
        for(let i=0;i<select.options.length;i++)
           select.options[i].selected = true; 
       
        this.form.appendChild(select);
        
        this.form.submit();   
    } 
});
</script>
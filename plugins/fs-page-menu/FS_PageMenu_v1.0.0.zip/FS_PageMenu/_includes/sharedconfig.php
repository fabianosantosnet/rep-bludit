<div id="descplg"><?php
 
 $NPLG=str_replace(' ','-',strtolower($this->name()));

 $dataTranslated = $L->get($NPLG.'-about-this-plugin-description'); 

 #replace keys to php data 
 $hideunhide='<span class="showData">+</span>';
 
 $dataTranslated= str_replace('#[fs{link-js-hide-unhide}]#',$hideunhide,$dataTranslated);
 
 $dataTranslated= str_replace('#[fs{plugin-description}]#',$this->description(),$dataTranslated);
 $dataTranslated= str_replace('#[fs{link-page-plugin}]#',$this->website().'#dev',$dataTranslated);
 $dataTranslated= str_replace('#[fs{link-social}]#','https://social.fabianosantos.net',$dataTranslated);
 $dataTranslated= str_replace('#[fs{link-page-doc-bludit}]#','https://fabianosantosnet.github.io/bluditCMS/',$dataTranslated);
 
 $dataTranslated= str_replace('#[fs{link-disable-plugin}]#',HTML_PATH_ADMIN_ROOT.'uninstall-plugin/'.$this->className(),$dataTranslated);
 
 if(!$this->isCompatible()) $dataTranslated.=$L->get('plugin-compatible-message');
    
 echo $dataTranslated;
 
 
?></div>

<div id="sharedconfig">
    
	<h3><?php echo $L->get('fs-shared-config-title').$hideunhide; ?></h3>
    
    <section class="wrap">
    
        <h4><?php echo $L->get('fs-shared-config-description'); ?></h4>

<?php	
    
	$html.='<div>';
    $html.='  <input type="button" name="btnAddSpace" id="btnAddSpace" value="+"> ';
    $html.='  <input type="reset" name="btnReset" id="btnReset" value="'.$L->get('Reset').'">';
	$html.='  <input type="button" name="btnSubSpace" id="btnSubSpace" value="-">';		    
    
	$html.=   '<div class="space">
                '.$L->get('fs-shared-config-space-desc');
	$html.='        <span class="tip">
                        <span id="spinfo"><span id="spaceinfo">0</span> '.$L->get('space(s) added').'</span>
                     </span>
                </div>';    
	$html.='  <input type="hidden" id="space" name="space" value="'.$this->getValue('space').'">';
    
	$html.='</div><br>';
    
	$html .= ' <div>'.    
                '<div class="inlineopt">'.$this->OptionEnableDisable('removeSpaces',false).'</div>'.
                $L->get('fs-shared-config-lbl-rem-space-code');               
	$html.= '  </div><br>';
	    
    /*   
	$html.= '<div>';
    $html.= '   <div class="inlineopt">'.$this->OptionEnableDisable('is_xhtml',false).'</div>';
	$html.=     $L->get('fs-shared-config-xhtml-desc');
	$html.= '</div><br>';*/
    
	$html.='<div> ';    	
	$html.= '   <div class="inlineopt">'.$this->OptionEnableDisable('showPluginLateralEnabled',false).'</div>';
    $html.=     $L->get('fs-shared-config-showplglateral-desc');
	$html.= '</div><br>';	
    
	$html.= '<div>';
    $html.= '   <div class="inlineopt">'.$this->OptionEnableDisable('hideEntryHTMLBlocks',false).'</div>';
	$html.=     $L->get('plugin-let-hide-entry');
	$html.= '</div><br>';
    
    $html.= '<div>';
    $html.= '   <div class="inlineopt">'.$this->OptionEnableDisable('updateDefaultViewJS',false).'</div>';
	$html.=     $L->get('fs-shared-config-update-default-view-js');
	$html.= '</div><br>';
    
    
	$divSwitchPlugins='<div id="switchplugin">';
	
	$divSwitchPlugins.= '<label>'.$L->get('fs-shared-config-lbl-order-plugins').'</label>';
    $divSwitchPlugins.= '  <ul id="OrderSubPlugins_LIST" name="OrderSubPlugins_LIST">'.PHP_EOL;
	
    if( empty($this->getValue('OrderSubPlugins') ) )
    {
      foreach($this->arDefault_plugins as $id=>$name) 	 
        $divSwitchPlugins.= '<li data-order="'.$id.'">'.$L->get($name).'</li>'.PHP_EOL;
    }
    else
    {
      $data=explode(',',$this->getValue('OrderSubPlugins'));
	  $d=$this->arDefault_plugins;
	  
		foreach($data as $id) 	
		{
			$divSwitchPlugins.= '<li data-order="'.$id.'">'.$L->get($d[$id]).'</li>'.PHP_EOL;		
		}
    }
		
	$divSwitchPlugins.= '</ul>';		
    $divSwitchPlugins.= '</div><br><br>';
    
    $html.=    $divSwitchPlugins;
    
    $html.='<div class="decor"><input type="button" name="btnSaveConfig" id="btnSaveConfig" value="'.$L->get('Save').'"></div>';
	echo $html;

?>	
   </section>
  </div><br>
<div class="base">
<?php		
		$html='<p class="copy"><strong>'.$this->name().'</strong> for <a href="https://bludit.com" target="_blank">BLUDIT CMS</a> by @fabianosantosnet<br><br>'.$L->get('send-me-tip').'<br><br></p>';
		
		echo $html;
?>
</div>
<?php
//Plugin by @fabianosantosnet for BLUDT CMS 2020
	
class pluginHeaderContent extends Plugin
{
	public function init()
	{	
		$this->dbFields = array
		(
			'robotstxt'=>'User-agent: *'.PHP_EOL.'Allow: /',
			'robotsEnabled'=>false,
			'canonicalEnabled'=>false,			
			'rssEnabled'=>false,
			'rssNumberOfItems'=>5,
			'space'=>'', 				# It refers to space in html code
			'is_xhtml'=>false, 			# add close tag for standard xhtml site			
			'authorNameEnabled'=>false,
			'copyrightNameEnabled'=>false,
			'keywordsEnabled'=>false,
			'descriptionEnabled'=>false,
			'authorName'=>'',
			'copyrightName'=>'',
			'showScriptUpdateBrowser'=>false,
			'MaintenanceModeEnabled'=>false,
			'htmlMaintenanceText'=>'',
			'cssBlockHeadEnabled'=>false,
			'css-block-txt'=>''
		);
	}

	public function beforeAll()
	{
		# INI PLUGIN ROBOTS
		# if($this->getValue('robotsEnabled'))
		#{		
			$webhook = 'robots.txt';			
			if($this->webhook($webhook))
			{
				header('Content-Type: text/plain');
				
				// Include link to sitemap in robots.txt if the plugin is enabled
				if ( pluginActivated('pluginSitemap') )
				{
					echo 'Sitemap: '.DOMAIN_BASE.'sitemap.xml'.PHP_EOL;
				}
				
				echo $this->getValue('robotstxt');
				exit(0);
			}
		#	}
		//END PLUGIN ROBOTS
		
		// INI RSS
		#if($this->getValue('rssEnabled'))
		#{
			$webhook = 'rss.xml';		
			if ($this->webhook($webhook))
			{
				// Send XML header
				header('Content-type: text/xml');
				$doc = new DOMDocument();

				// Load XML
				libxml_disable_entity_loader(false);
				$doc->load($this->workspace().'rss.xml');
				libxml_disable_entity_loader(true);

				// Print the XML
				echo $doc->saveXML();

				// Stop Bludit execution
				exit(0);
			}
		#}
		// END RSS		
		
		if( $this->getValue('MaintenanceModeEnabled') )
		{	
			if(!file_exists(THEME_DIR_PHP.'maintenance.php') )
			{	
				global $site;
				
				# Template default
				$html=
				'<!DOCTYPE html>
				<html lang="en" dir="ltr">
				<head>
				<meta http-equiv="X-UA-Compatible" content="IE=Edge">
				<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
				<meta charset="utf-8">'.	
				'<title>'.$site->title().'</title>
				<meta name="robots" content="noydir,noindex,noarchive,nofollow">
				<style>
					div {width:70%;max-width:800px;padding:1rem 3rem;margin:auto;background-color:#eee;text-align:center; font-family:arial !important;border-radius:6px}
					div h1 {font-size:3.6rem;padding:1rem;color:#444;text-shadow:1px 1px 5px #bbb}
					div h1 a {text-decoration:none;color:#777}
					div p {font-size:2rem;padding:1rem;color:#777;margin-top:-1rem}
					@media (max-width:600px) { div {width:100%;padding:1rem 0} div h1 {font-size:3rem} div p {font-size:1.6rem} }
					@media (max-width:400px) { div h1 {font-size:2rem} div p {font-size:1rem} }					   
			    </style>
				
				</head>
				<body>'.
				  '<div class="info"><h1><a href="'.$site->url().'">'.$site->title().'</a></h1><p>'.$this->getValue('htmlMaintenanceText').'</p>				  
				  </div>
				</body>
				</html>';
				
			  exit($html);
			}
		    else 
			  exit( require_once(THEME_DIR_PHP.'maintenance.php') );
		}
	}


	public function siteHead()
	{	
		global $WHERE_AM_I,$page;
				
		$space=$this->getValue('space');
		$html='';		
		
		//ROBOTS
		if($this->getValue('robotsEnabled'))
		{
			$html.=$space.PHP_EOL;
			
			if ($WHERE_AM_I=='page')
			{	
				$robots = array();

				if ($page->noindex())  $robots['noindex']  = 'noindex';			
				if ($page->nofollow()) $robots['nofollow'] = 'nofollow';
				if ($page->noarchive()) $robots['noarchive'] = 'noarchive';
				
				if (!empty($robots))
				{
					$robots = implode(',', $robots);
					$html .= $space.'<meta name="robots" content="'.$robots.'">'.PHP_EOL;
				}
			}	
		}

		//Author and Copyright
		if($this->getValue('authorNameEnabled'))
		{
			$html .= $space.'<meta name="author" content="'.$this->getValue('authorName').'">'.PHP_EOL;
		}
		
		if($this->getValue('copyrightNameEnabled'))
		{
			$html .= $space.'<meta name="copyright" content="'.$this->getValue('copyrightName').'">'.PHP_EOL;
		}		
		//END Author and Copyright
		
		# INI KEYWORDS
		if($this->getValue('keywordsEnabled'))
		{
			$keypage='';
			
			if($page) #prevent error
			{
				if( $page->custom('keywords') )
				{
					$keypage=$page->custom('keywords');
					
					$html .= $space.'<meta name="keywords" content="'.$keypage.'">'.PHP_EOL;
				}
			}
		}	
		# END KEYWORDS
		
		# INI DESCRIPTION
		if($this->getValue('descriptionEnabled'))
		{	
			$html .= $space.Theme::metaTagDescription().PHP_EOL;			
		}	
		# END DESCRIPTION
		
		//CANONICAL
		if($this->getValue('canonicalEnabled'))
		{
			if($WHERE_AM_I === 'home')
			  $html .= $space.'<link rel="canonical" href="'.DOMAIN_BASE.'">'.PHP_EOL;
		  
			elseif($WHERE_AM_I === 'page')		
			  $html .= $space.'<link rel="canonical" href="'.$page->permalink().'">'.PHP_EOL;
		}
		
		// RSS
		if($this->getValue('rssEnabled'))
		{
			if( !pluginActivated('pluginRSS') )
				$html .= $space.'<link rel="alternate" type="application/rss+xml" href="'.DOMAIN_BASE.'rss.xml" title="RSS Feed">'.PHP_EOL;			
			
			#	else { 
			#		echo '</head><body><h1>Plugin HeaderContent error: Please desactive "RSS Feed" Plugin, this functionality is already implemented and active !</h1></body></html>';exit(0);
			#	}
		}
		
		# XML / XTML Tag
		if( $this->getValue('is_xhtml') )
			$html=str_replace('">','" />',$html);


		# INI CSS BLOCK
		if($this->getValue('cssBlockHeadEnabled'))
		{
			if($this->getValue('css-block-txt'))
				$html .= '
'.$space.'<style>
'.$this->getValue('css-block-txt').'
'.$space.'</style>
';
		}
		# END CSS BLOCK		
		
		# BrowserNotify Script
		if( $this->getValue('showScriptUpdateBrowser') )
		$html.=
'
	<!-- This script show message for old/outdate browsers to update -->
	<script>
		var $buoop = {required:{e:-3,f:-3,o:-3,s:-1,c:-3},insecure:true,api:2020.06 }; 
		function $buo_f(){ 
		 var e = document.createElement("script"); 
		 e.src = "//browser-update.org/update.min.js"; 
		 document.body.appendChild(e);
		};
		try {document.addEventListener("DOMContentLoaded", $buo_f,false)}
		catch(e){window.attachEvent("onload", $buo_f)}
	</script>
';
		return $html;
	}
		
	
	public function form()
	{
		global $L;
		
		$html='<style>
					div.plugin-info {background:#f5f5f5;margin-top:2rem}
					div.plugin-info h2 {padding:0.5rem 1rem;background:#eee;color:#999;text-transform:uppercase;font-size:1.2rem;font-weight:bold}
					div.plugin-info h3 {padding:1rem;font-size:1rem}
					div.plugin-info div.plug-content {margin:1rem !important;padding:1rem !important;margin-top:-2rem !important}
					div.plugin-info div.plug-content label {}
					div.plugin-info div.plug-content textarea {}
					div.plugin-info div.plug-content .inline {display:inline-block !important;margin:0;width:4rem}
					div.plug-content .optionplugin {width:auto !important;display:inline-block;border-radius:0;height:auto;padding:0.1rem}										
					div.status {width:140px;float:right;margin:2.5rem 1rem}
					div.decor-separator {height:1rem;background:#fff;width:100%}
					.inline {width:5rem !important;border:1px double; border-radius:0 !important;height:2rem;padding:0 !important;margin:0 !important}
					.w200 {width:200px !important}
					.w400 {width:400px !important}
					.w600 {width:400px !important}
					.wauto {width:84% !important}
					p.error-info {display:block;width:100%;background:#ffb;color:red;font-weight:bold;padding:1rem}
					.pad-5px {padding-left:5px !important}
					code {background:#f0f0ee;font-family:monospace;margin:0;padding:2px}
					p.copy {background:#f0f0f0;padding:1rem}
					code.pre {white-space:pre;display:block;padding:0 1rem;font-size:0.78em;background:#eee;color:#888}
				</style>'.PHP_EOL;
		
		$spc='&nbsp;&nbsp;&nbsp;&nbsp;';
		//INI SHARED			
		$pluginName=$L->get('share-config-name');		
		$pluginDesc=$spc.$L->get('share-config-description');
		
		$pluginLabel='';
		$content=$L->get('share-config-space-desc').'<input class="inline" type="text" name="space" id="jsspace" value="'.$this->getValue('space').'" 
														onkeyup="document.getElementById(\'spaceinfo\').innerHTML=this.value.length">
														 <span id="spaceinfo"></span><br><br>
				  '.$L->get('share-config-xhtml-desc').$this->OptionDisableEnable('is_xhtml',false);								
		
		$status='';
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);

		// INI SCRIPT BROWSER UPDATE
		$pluginName =$L->get('browserscript-name');
		$pluginLabel=$L->get('browserscript-description');
		$pluginDesc ='';
		$status=$this->OptionDisableEnable('showScriptUpdateBrowser');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END SCRIPT BROWSER UPDATE
		
		// INI CANONICAL
		$pluginName =$L->get('canonical-name');
		$pluginDesc =$spc.$L->get('canonical-description');
		$pluginLabel='';
		$status=$this->OptionDisableEnable('canonicalEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END CANONICAL
		
		//INI ROBOTS			
		$pluginName=$L->get('robots-name');		
		$pluginDesc=$L->get('robots-description');
		
		$pluginLabel=DOMAIN.'/robots.txt';
		$content='<textarea name="robotstxt" id="jsrobotstxt">'.$this->getValue('robotstxt').'</textarea>';
		
		$status=$this->OptionDisableEnable('robotsEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);
		//END ROBOTS
		
		// INI KEYWORDS
		$pluginName =$L->get('keywords-name');
		$pluginDesc =$L->get('keywords-description');
		$pluginLabel='		
<code class="pre">
{
  "keywords":
  {
    <b>"type"</b>: "string",
    <b>"label"</b>: "Set keywords for this article",
    <b>"position"</b>: "bottom"
  }
}
</code>
		';
		$status=$this->OptionDisableEnable('keywordsEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END KEYWORDS		
		
		// INI DESCRIPTION
		$pluginName =$L->get('description-name');
		$pluginDesc =$spc.$L->get('description-description');
		$pluginLabel='';
		$status=$this->OptionDisableEnable('descriptionEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END DESCRIPTION
		
		// INI AUTHOR
		$pluginName =$L->get('author-name');
		$pluginDesc ='';
		$pluginLabel=$L->get('author-description').' <input type="text" name="authorName" id="authorName" value="'.$this->getValue('authorName').'" class="inline w200 pad-5px">';
		$status=$this->OptionDisableEnable('authorNameEnabled');
		$content='';
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);	
		// END AUTHOR
		
		// INI COPYRIGHT
		$pluginName =$L->get('copyright-name');
		$pluginDesc ='';
		$pluginLabel='';
		$status=$this->OptionDisableEnable('copyrightNameEnabled');
		$content=$L->get('copyright-description').' <input type="text" name="copyrightName" id="copyrightName" value="'.$this->getValue('copyrightName').'" class="inline w400 pad-5px">';
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);	
		// END COPYRIGHT

		//INI RSS		
		$content='';
		if( pluginActivated('pluginRSS'))
		$content.='<p class="error-info">'.$L->get('rss-error-message').'</p>';
		
		$content  .= $L->get('rss-amount-of-items').
					'<input id="jsrssNumberOfItems" name="rssNumberOfItems" class="inline pad-5px" type="text" value="'.$this->getValue('rssNumberOfItems').'">';		
		
		$rssURL=DOMAIN_BASE.'rss.xml';#only if rss is active
		
		$pluginName =$L->get('rss-name');
		$pluginDesc =$L->get('rss-description');
		$pluginLabel=$L->get('RSS URL').' - <a href="'.$rssURL.'">'.$rssURL.'</a>';
		$status=$this->OptionDisableEnable('rssEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);		
		//END RSS
		
		//INI CSS STYLE
		$pluginName=$L->get('css-block-name');		
		$pluginDesc=$L->get('css-block-description');
		
		$pluginLabel='';
		$content='<textarea name="css-block-txt" id="css-block-txt">'.$this->getValue('css-block-txt').'</textarea>';
		
		$status=$this->OptionDisableEnable('cssBlockHeadEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);
		//END CSS STYLE	

		// INI MAINTENANCE
		$pluginName =$L->get('maintenance-name');
		$pluginDesc =$spc.$L->get('maintenance-description');
		$pluginLabel='';
		$status=$this->OptionDisableEnable('MaintenanceModeEnabled');
		
		$msg='';
		if( !empty($this->getValue('htmlMaintenanceText')) )
		 $msg = $this->getValue('htmlMaintenanceText');
	    else
		 $msg = $L->get('maintenance-info-message');
	    
		$content=' <input type="text" name="htmlMaintenanceText" id="htmlMaintenanceText" value="'.$msg.'" class="inline wauto pad-5px"><br><br>'.$L->get('maintenance-personal-file');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);			
		// END MAINTENANCE			
		
		$html.='<hr><br><p class="copy">BLUDIT CMS Plugin Header Content by @fabianosantosnet. '.$L->get('send-me-tip').'</p><br><br>';
		
		return $html;
	}

	public function siteSidebar()
	{
		$html='';
		
		return $html;
	}
	
	
	# INI RSS FUNCTION
	private function encodeURL($url)
	{
	   return preg_replace_callback('/[^\x20-\x7f]/', function($match) { return urlencode($match[0]); }, $url);
	}
	
	private function rss_createXML()
	{
		global $site;
		global $pages;
		global $url;

		// Amount of pages to show
		$numberOfItems = $this->getValue('rssNumberOfItems');

		// Get the list of public pages (sticky and static included)
		$list = $pages->getList
		(
			$pageNumber=1,
			$numberOfItems,
			$published=true,
			$static=true,
			$sticky=true,
			$draft=false,
			$scheduled=false
		);

		$xml = '<?xml version="1.0" encoding="UTF-8" ?>';
		$xml .= '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">';
		$xml .= '<channel>';
		$xml .= '<atom:link href="'.DOMAIN_BASE.'rss.xml" rel="self" type="application/rss+xml" />';
		$xml .= '<title>'.$site->title().'</title>';
		$xml .= '<link>'.$this->encodeURL($site->url()).'</link>';
		$xml .= '<description>'.$site->description().'</description>';
		$xml .= '<lastBuildDate>'.date(DATE_RSS).'</lastBuildDate>';

		// Get keys of pages
		foreach ($list as $pageKey)
		{
			try 
			{
				// Create the page object from the page key
				$page = new Page($pageKey);
				$xml .= '<item>';
				$xml .= '<title>'.$page->title().'</title>';
				$xml .= '<link>'.$this->encodeURL($page->permalink()).'</link>';
				$xml .= '<description>'.Sanitize::html($page->contentBreak()).'</description>';
				$xml .= '<pubDate>'.date(DATE_RSS,strtotime($page->getValue('dateRaw'))).'</pubDate>';
				$xml .= '<guid isPermaLink="false">'.$page->uuid().'</guid>';
				$xml .= '</item>';
			} 
			catch (Exception $e) 
			{
				// Continue
			}
		}

		$xml .= '</channel>
				</rss>';

		// New DOM document
		$doc = new DOMDocument();
		$doc->formatOutput = true;
		$doc->loadXML($xml);
		
		return $doc->save($this->workspace().'rss.xml');
	}

	public function install($position=0)
	{
		parent::install($position);		
		return $this->rss_createXML();
	}

	public function post()
	{ 
		parent::post();		
		return $this->rss_createXML();		
	}

	public function afterPageCreate() { $this->rss_createXML(); }

	public function afterPageModify() { $this->rss_createXML();	 }	

	public function afterPageDelete() { $this->rss_createXML();	}	
	
	# END RSS FUNCTION
	
	
	# UTILS FUNCTIONS
	private function baseHTML($pluginStatus,$pluginName,$pluginDesc,$pluginLabel,$content)
	{
		$html = '<div role="alert" class="plugin-info">'.
		'<div class="status">'.$pluginStatus.'</div>'.
		'<h2 class="plug-title">'.$pluginName.'</h2>'.
		'<h3 class="plug-desc">'.$pluginDesc.'</h3>'.
		'<div class="plug-content">
			<p><label>'.$pluginLabel.'</label></p> 
			  '.$content.'
		 </div>
		';	
		
		return $html;
	}
	
	private function OptionDisableEnable($var,$showstatus=true)
	{
		global $L;
		
		$html='';
		
		if($showstatus) $html.= '<span>'.$L->get('Plugin Status').'</span>';
		
		$html.= '
				<select name="'.$var.'" class="optionplugin">
					 <option value="true" '.($this->getValue($var)===true?'selected':'').'>'.$L->get('Enabled').'</option>
					 <option value="false" '.($this->getValue($var)===false?'selected':'').'>'.$L->get('Disabled').'</option>
				</select>';

		return $html;
	}
}
<?php
//Plugin by @fabianosantosnet for BLUDT CMS 2023

if(file_exists(PATH_PLUGINS.'_DEBUG.php')) require_once(PATH_PLUGINS.'_DEBUG.php');

class pluginHeaderContent extends Plugin
{
	public function init()
	{	
		$this->dbFields = array
		(
			'robotstxt'=>'User-agent: *'.PHP_EOL.'Allow: /',
			'robotsEnabled'=>false,
			'categoryNoIndexEnabled'=>false,
			'tagNoIndexEnabled'=>false,
			'canonicalEnabled'=>false,			
			'rssEnabled'=>false,
			'rssNumberOfItems'=>5,
            'rssMaxNumChars'=>-1,
            'rssNotShowingNoIndexPage'=>false,
			'space'=>'', 				# It refers to space in html code
			'is_xhtml'=>false, 			# add close tag for standard xhtml site			
			'authorNameEnabled'=>false,
			'copyrightNameEnabled'=>false,
			'keywordsEnabled'=>false,
			'keywordsOnHomePageText'=>'',
			'descriptionEnabled'=>false,
			'authorName'=>'',
			'copyrightName'=>'',
			'showScriptUpdateBrowser'=>false,
			'MaintenanceModeEnabled'=>false,
			'htmlMaintenanceText'=>'',
			'cssBlockHeadEnabled'=>false,
			'css-block-txt'=>''
		);
	}

	public function beforeAll()
	{	
		# INI PLUGIN ROBOTS
		if($this->getValue('robotsEnabled'))
		{		
			$webhook = 'robots.txt';			
			if($this->webhook($webhook))
			{
				header('Content-Type: text/plain');
				
				echo $this->getValue('robotstxt');
				
				// Include link to sitemap in robots.txt if the plugin is enabled
				if ( pluginActivated('pluginSitemap') or pluginActivated('pluginFS_SEO') )				
					echo PHP_EOL.PHP_EOL.'Sitemap: '.DOMAIN_BASE.'sitemap.xml';
				
				exit(0);
			}
		}
		//END PLUGIN ROBOTS
		
		// INI RSS
		if($this->getValue('rssEnabled'))
		{
            $webhook = 'rss.xml';		
            if ($this->webhook($webhook))
            {
                // Send XML header
                header('Content-type: text/xml');
                $doc = new DOMDocument();

                // Load XML
                libxml_disable_entity_loader(false);
                $doc->load($this->workspace().'rss.xml');
                libxml_disable_entity_loader(true);

                // Print the XML
                echo $doc->saveXML();

                // Stop Bludit execution
                exit(0);
            }
		}
		// END RSS		
		
		if( $this->getValue('MaintenanceModeEnabled') )
		{	
			if(!file_exists(THEME_DIR_PHP.'maintenance.php') )
			{	
				global $site;
				
				# Template default
				$html=
				'<!DOCTYPE html>
				<html lang="en" dir="ltr">
				<head>
				<meta http-equiv="X-UA-Compatible" content="IE=Edge">
				<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
				<meta charset="utf-8">'.	
				'<title>'.$site->title().'</title>
				<meta name="robots" content="noydir,noindex,noarchive,nofollow">
				<style>
					div {width:70%;max-width:800px;padding:1rem 3rem;margin:auto;background-color:#eee;text-align:center; font-family:arial !important;border-radius:6px}
					div h1 {font-size:3.6rem;padding:1rem;color:#444;text-shadow:1px 1px 5px #bbb}
					div h1 a {text-decoration:none;color:#777}
					div p {font-size:2rem;padding:1rem;color:#777;margin-top:-1rem}
					@media (max-width:600px) { div {width:100%;padding:1rem 0} div h1 {font-size:3rem} div p {font-size:1.6rem} }
					@media (max-width:400px) { div h1 {font-size:2rem} div p {font-size:1rem} }					   
			    </style>
				
				</head>
				<body>'.
				  '<div class="info"><h1><a href="'.$site->url().'">'.$site->title().'</a></h1><p>'.$this->getValue('htmlMaintenanceText').'</p>
				  </div>
				</body>
				</html>';
				
			  exit($html);
			}
		    else 
			  exit( require_once(THEME_DIR_PHP.'maintenance.php') );
		}
	}


	public function siteHead()
	{	
		global $WHERE_AM_I,$page;
				
		$space=$this->getValue('space');
		$html='';	
        $canonicalData='';
		
		//CANONICAL
		if($this->getValue('canonicalEnabled'))
		{
            if($WHERE_AM_I === 'home')
              $canonicalData .= $space.'<link rel="canonical" href="'.DOMAIN_BASE.'">'.PHP_EOL;
          
            elseif($WHERE_AM_I === 'page')		
            {
                if($this->CheckIfPageExists()) #it only shows on existed pages
                    $canonicalData .= $space.'<link rel="canonical" href="'.$page->permalink().'">'.PHP_EOL;
            }
            
            if(!$this->getValue('robotsEnabled'))
                $html.=$canonicalData;
		}
		
		// RSS
		if($this->getValue('rssEnabled'))
		{
			if( !pluginActivated('pluginRSS') )
				$html .= $space.'<link rel="alternate" type="application/rss+xml" href="'.DOMAIN_BASE.'rss.xml" title="RSS Feed">'.PHP_EOL;	
		}
		
		//ROBOTS
		if($this->getValue('robotsEnabled'))
		{
			$html.=$space.PHP_EOL;
			
			$robots = array();
				
			if ($WHERE_AM_I=='page')
			{	
				if ($page->noindex())  $robots['noindex']  = 'noindex';
				if ($page->nofollow()) $robots['nofollow'] = 'nofollow';
				if ($page->noarchive()) $robots['noarchive'] = 'noarchive';
			
                # Prevent search engines to index pages that doesn't exist | it also checks on tags and categories
				if(!$this->CheckIfPageExists())
				{
					$robots['noindex']  = 'noindex';
					$robots['nofollow'] = 'nofollow';
					$robots['noarchive'] = 'noarchive';
				}					
				# END				
			} 
			else if( $WHERE_AM_I == 'category')
			{
				if($this->getValue('categoryNoIndexEnabled'))
				{
				  $robots['noindex']  = 'noindex';     
				  $robots['follow']  = 'follow';
				}
			}
			else if( $WHERE_AM_I == 'tag' )
			{			
				if($this->getValue('tagNoIndexEnabled'))
				{
				  $robots['noindex']  = 'noindex';			  
				  $robots['follow']  = 'follow';
				}
			}					
			
			if (!empty($robots))
			{
                if(!in_array($robots,'noindex') && !$this->getValue('canonicalEnabled')) # avoid noindex and canonical on same page
                 $html.=$space.$canonicalData;
             
				$robots = implode(',', $robots);
				$html .= $space.'<meta name="robots" content="'.$robots.'">'.PHP_EOL;
			}				
            else
                 $html.=$space.$canonicalData;
		}

		//Author and Copyright
		if($this->getValue('authorNameEnabled'))
		{
			$html .= $space.'<meta name="author" content="'.$this->getValue('authorName').'">'.PHP_EOL;
		}
		
		if($this->getValue('copyrightNameEnabled'))
		{
			$html .= $space.'<meta name="copyright" content="'.$this->getValue('copyrightName').'">'.PHP_EOL;
		}		
		//END Author and Copyright
		
		# INI KEYWORDS
		if($this->getValue('keywordsEnabled'))
		{
			$keypage='';
			
			if($page) #prevent error
			{
				if( $page->custom('keywords') )
				{
					$customkey=$page->custom('keywords');
					
					if(strlen($customkey)>0 and $WHERE_AM_I !='home' and $WHERE_AM_I !='category' and $WHERE_AM_I !='tag') #ignored category and tag to avoid recent article to add its keywords to this 'place'
					 $html .= $space.'<meta name="keywords" content="'.$customkey.'">'.PHP_EOL;
				}
				
				if($WHERE_AM_I =='home')
				{	
					if($this->getValue('keywordsOnHomePageText'))
					{
						$homekeypage=$this->getValue('keywordsOnHomePageText');	
						
						if(strlen($homekeypage)>0)
						{
						  $keypage='<meta name="keywords" content="'.$homekeypage.'">';						
						  $html .= $space.$keypage.PHP_EOL;	
						}
					}
				}
			}
		}	
		# END KEYWORDS
		
		# INI DESCRIPTION
		if($this->getValue('descriptionEnabled'))
		{	
			$html .= $space.Theme::metaTagDescription().PHP_EOL;			
		}	
		# END DESCRIPTION
		
		# XML / XHTML Tag
		if( $this->getValue('is_xhtml') )
			$html=str_replace('">','" />',$html);


		# INI CSS BLOCK
		if($this->getValue('cssBlockHeadEnabled'))
		{
			if($this->getValue('css-block-txt'))
				$html .= '
'.$space.'<style>
'.$this->getValue('css-block-txt').'
'.$space.'</style>
';
		}
		# END CSS BLOCK		
		
		# BrowserNotify Script
		if( $this->getValue('showScriptUpdateBrowser') )
		$html.=$space.'<!-- This script shows a message to update the browser -->
'.$space.'<script> 
            var $buoop = {required:{e:-4,f:-3,o:-3,s:-1,c:-3},insecure:true,api:2023.05 }; 
            function $buo_f(){ 
             var e = document.createElement("script"); 
             e.src = "//browser-update.org/update.min.js"; 
             document.body.appendChild(e);
            };
            try {document.addEventListener("DOMContentLoaded", $buo_f,false)}
            catch(e){window.attachEvent("onload", $buo_f)}
'.$space.'</script>
';
		return $html;
	}
		
	
	public function form()
	{
		global $L;
		
		$html='<style>

					form.plugin-form > div:first-of-type > h2 {padding:1rem;background:#f5f5f5;border-bottom:1rem solid #eee}
					form.plugin-form > div:first-of-type {margin-top:-0.7rem}
					form.plugin-form > div.align-middle > div {padding:1rem}
					.plgact_message {display:block;padding:1rem;background-color:#ffe;color:red;font-size:0.77rem;margin-top:0.8rem;margin-bottom:-1.4rem}
					
					div.plugin-info,#fs_plg_all {background:#f5f5f5;margin-top:2rem;clear:both}
					div.plugin-info h2 {padding:0.5rem 1rem;background:#eee;color:#999;text-transform:uppercase;font-size:1.2rem;font-weight:bold}
					div.plugin-info h3 {padding:1rem;font-size:1rem}
					
					div.plugin-info div.plug-content {margin:1rem !important;padding:1rem !important;margin-top:-2rem !important}
					div.plugin-info .lbldata {margin-left:1.2rem;margin-bottom:-0.2rem}
					div.plugin-info div.plug-content label {}
					div.plugin-info div.plug-content textarea {}
					div.plugin-info div.plug-content .inline {display:inline-block !important;margin:0;width:4rem}
					
					div.plug-content .optionplugin {width:auto !important;display:inline-block;border-radius:0;height:auto;padding:0.1rem}										
					div.status {width:140px;float:right;margin:2.5rem 0rem;;margin-top:0.2rem;padding:0.5rem;background:#eee}
					div.decor-separator {height:1rem;background:#fff;width:100%}
					
					.ronly {margin-top:1px;background:#fcfcfc !important;border:1px double; border-radius:0  0 5px 5px !important}				
					.txtar { border-radius:5px 5px 0 0 !important}					
					.inline {width:5rem !important;border:1px double; border-radius:0 !important;height:2rem;padding:0 !important;margin:0 !important}
					.w200 {width:200px !important}
					.w400 {width:400px !important}
					.w600 {width:400px !important}
					.wauto {width:84% !important}
					.wautoo {width:100% !important}
					.upnow	{margin:-2rem 0rem}
					.upnow input {margin-top:4px !important}
					
					p.error-info {display:block;width:100%;background:#ffb;color:red;font-weight:bold;padding:1rem}
					.pad-5px {padding-left:5px !important}
					code {background:#f0f0ee;font-family:monospace;margin:0;padding:2px}
					code.pre {white-space:pre;display:block;padding:0 1rem;font-size:0.78em;background:#eee;color:#888}
					p.copy {background:#f0f0f0;padding:1rem}					
					div.plugin-info .sub{padding:1rem;background:#f1f1f1}
					span.link {background-color:#f0f0f0;padding:0.3rem}
					
					div.plugin-info .twoopt {display:block;max-width:600px;margin:1rem auto;min-height:100px;background:#f0f0f0;padding:0rem 1rem;clear:both}
					div.plugin-info .twoopt > label {background:#dfdfdf;padding:0.4rem 1rem;margin:0 -1rem}
					div.plugin-info .twoopt div {width:49%;float:left;margin:1px}
					div.plugin-info .twoopt div span {display:inline;padding:0.3rem}
					div.plugin-info .twoopt div label {background:#dd;display:inline-block}	
					#fs_plg_all .plugin-info p.toplink {width:100%;position:relative}
					p.toplink a {float:right;color:#bbb;font-size:0.8rem}
					p.toplink a:hover {color:#777}
				
				</style>
				
				<div id="fs_plg_all">
				'.PHP_EOL;
		
        $toplink='<p class="toplink"><a href="#top">[top]</a></p>';
        
		$lbl='<div class="lbldata">';
		$lble='</div>';
		#$spc='';
		//INI SHARED			
		$pluginName=$L->get('share-config-name');		
		$pluginDesc=$lbl.$L->get('share-config-description').$lble;
		
		$pluginLabel='';
		$content=$L->get('share-config-space-desc').'<input class="inline" type="text" name="space" id="jsspace" value="'.$this->getValue('space').'" 
														onkeyup="document.getElementById(\'spaceinfo\').innerHTML=this.value.length">
														 <span id="spaceinfo"></span><br><br>
				  '.$L->get('share-config-xhtml-desc').$this->OptionDisableEnable('is_xhtml',false);								
		
		$status='';
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);

		// INI SCRIPT BROWSER UPDATE
		$pluginName =$L->get('browserscript-name');
		$pluginLabel='';
		$pluginDesc =$lbl.$L->get('browserscript-description').$lble;
		$status=$this->OptionDisableEnable('showScriptUpdateBrowser');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END SCRIPT BROWSER UPDATE
		
		// INI CANONICAL
		$pluginName =$L->get('canonical-name');
		$pluginDesc =$lbl.$L->get('canonical-description').$lble;
		$pluginLabel='';
		
		$status="";
		
	    if ( getPlugin('pluginCanonical') ) { $status= "<span class='plgact_message'>".$L->get('plg-canonical-already-running')."</span>";}
	    else $status=$this->OptionDisableEnable('canonicalEnabled');
		
		
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,'');		
		//END CANONICAL
		
		//INI ROBOTS			
		$pluginName=$L->get('robots-name');		
		$pluginDesc=$lbl.$L->get('robots-description').$lble;
		
		$pluginLabel='<span class="link"><a href="'.DOMAIN_BASE.'robots.txt'.'">'.DOMAIN_BASE.'robots.txt'.'</a></span>';
				
		$content='<textarea name="robotstxt" class="txtar" id="jsrobotstxt">'.$this->getValue('robotstxt').'</textarea>';

		$smap = '';
		if ( pluginActivated('pluginSitemap') or pluginActivated('pluginFS_SEO') )
		{
			$smap = 'Sitemap: '.DOMAIN_BASE.'sitemap.xml'.PHP_EOL;
		
			$content.='<input type="text" readonly value=\''.$smap.'\' class="ronly">'.PHP_EOL;
		}
		
		$status="";		
	    if ( getPlugin('pluginRobots') ) { $status= "<span class='plgact_message'>".$L->get('plg-robots-already-running')."</span>";}
	    else $status=$this->OptionDisableEnable('robotsEnabled');
		
		$content.='
		<div class="twoopt">
		  <label>'.$L->get('robots-opt-desc').'</label>
		  <div>
		    <label>'.$L->get('robots-opt-catnoindex-desc').'</label>
		    <span>'.$this->OptionDisableEnable('categoryNoIndexEnabled',false).'</span>
		  </div>
		  
		  <div>
		    <label>'.$L->get('robots-opt-tagnoindex-desc').'</label>
		    <span>'.$this->OptionDisableEnable('tagNoIndexEnabled',false).'</span>
		  </div>		  
		</div>
		
		'.$toplink;
		
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);
		//END ROBOTS
		
		// INI KEYWORDS
		$pluginName =$L->get('keywords-name');
		$pluginDesc =$lbl.$L->get('keywords-description').$lble;
		$pluginLabel='		
<code class="pre">
{
  "keywords":
  {
    <b>"type"</b>: "string",
    <b>"label"</b>: "Set keywords for this article",
    <b>"position"</b>: "bottom"
  }
}

</code>
		';
		    $status=$this->OptionDisableEnable('keywordsEnabled');
		
			// INI HOME KEYWORDS
			$msg='';
			if( !empty($this->getValue('keywordsOnHomePageText')) )
			 $msg = $this->getValue('keywordsOnHomePageText');	    
			
			$content='<div class="sub">';
			$content.=$L->get('keyword-homepage-description').' <input type="text" name="keywordsOnHomePageText" id="keywordsOnHomePageText" value="'.$msg.'" class="inline wautoo pad-5px">';
			$content.='</div><br>';			
            $content.=$toplink;
			// END  HOME KEYWORDS		
		
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);
		//END KEYWORDS		
		
		// INI DESCRIPTION
		$pluginName =$L->get('description-name');
		$pluginDesc =$lbl.$L->get('description-description').$lble;
		$pluginLabel='';
		$status=$this->OptionDisableEnable('descriptionEnabled');        
        $content=$toplink;
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);        
		//END DESCRIPTION
		
		// INI AUTHOR
		$pluginName =$L->get('author-name');
		$pluginDesc ='';
		$pluginLabel='<div class="upnow">'.$L->get('author-description').' <br><input type="text" name="authorName" id="authorName" value="'.$this->getValue('authorName').'" class="inline wauto pad-5px"></div>';
		$status=$this->OptionDisableEnable('authorNameEnabled');
		$content='<br>'.$toplink;
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);	
		// END AUTHOR
		
		// INI COPYRIGHT
		$pluginName =$L->get('copyright-name');
		$pluginDesc ='';
		$pluginLabel='';
		$status=$this->OptionDisableEnable('copyrightNameEnabled');
		$content='<div class="upnow">'.$L->get('copyright-description').' <br><input type="text" name="copyrightName" id="copyrightName" value="'.$this->getValue('copyrightName').'" class="inline wauto pad-5px"></div>';
        $content.='<br><br>'.$toplink;
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);	

		// END COPYRIGHT

		//INI RSS		
		$content='';
		$status2='';
		$er_RSS='';
		if( pluginActivated('pluginRSS') )
		   $er_RSS="<span class='plgact_message'>".$L->get('plg-rss-already-running')."</span><br><br><br>";
	   
	    else 
		    $status2=$this->OptionDisableEnable('rssEnabled');
		
		$content  .= '<br>'.$L->get('rss-amount-of-items').
					'<input id="jsrssNumberOfItems" name="rssNumberOfItems" class="inline pad-5px" type="text" value="'.$this->getValue('rssNumberOfItems').'"><br>';		
		
        $content.='<br>'.$L->get('rss-max-num-characters').' <input type="text" name="rssMaxNumChars" id="rssMaxNumChars" value="'.$this->getValue('rssMaxNumChars').'" class="inline pad-5px">';        
        $content.='	<span class="tip">'.$L->get('rss-max-num-characters-tip').'</span><br>';
        $content.=$L->get('rss-not-showing-noindex-page-label').' '. $this->OptionCheckBox('rssNotShowingNoIndexPage');
        $content.='	<span class="tip">'.$L->get('rss-not-showing-noindex-page-tip').'</span>';
        
        $rssURL=DOMAIN_BASE.'rss.xml';#only if rss is active
        		
		$pluginName =$L->get('rss-name');
		$pluginDesc =$er_RSS.$lbl.$L->get('rss-description').$lble;
		$pluginLabel='<span class="link">'.$L->get('RSS URL').': <a href="'.$rssURL.'">'.$rssURL.'</a></span><br><br><hr>';
		$content.=$toplink;
		$html.=$this->baseHTML($status2,$pluginName,$pluginDesc,$pluginLabel,$content);		
        //END RSS
		
		//INI CSS STYLE
		$pluginName=$L->get('css-block-name');		
		$pluginDesc=$lbl.$L->get('css-block-description').$lble;
		
		$pluginLabel='';
		$content='<textarea name="css-block-txt" id="css-block-txt">'.$this->getValue('css-block-txt').'</textarea><br>'.$toplink;
		
		$status=$this->OptionDisableEnable('cssBlockHeadEnabled');
		$html.=$this->baseHTML($status,$pluginName,$pluginDesc,$pluginLabel,$content);                
		//END CSS STYLE	

		// INI MAINTENANCE
		
		$er_RSS='';
		$status3='';

	    if ( getPlugin('pluginMaintenanceMode') ) { $status3= "<span class='plgact_message'>".$L->get('plg-mmode-already-running')."</span>";}
	    else $status3=$this->OptionDisableEnable('MaintenanceModeEnabled');
		
		$pluginName =$L->get('maintenance-name');
		$pluginDesc =$lbl.$L->get('maintenance-description').$lble;
		$pluginLabel='';
		
		
		$msg='';
		if( !empty($this->getValue('htmlMaintenanceText')) )
		 $msg = $this->getValue('htmlMaintenanceText');
	    else
		 $msg = $L->get('maintenance-info-message');
	    
		$content=' <input type="text" name="htmlMaintenanceText" id="htmlMaintenanceText" value="'.$msg.'" class="inline wauto pad-5px"><br><br>'.$L->get('maintenance-personal-file').$toplink;;
		$html.=$this->baseHTML($status3,$pluginName,$pluginDesc,$pluginLabel,$content);			
		// END MAINTENANCE			
		
		$html.='<hr><br><p class="copy">BLUDIT CMS Plugin Header Content by @fabianosantosnet. '.$L->get('send-me-tip').'</p><br><br></div>';
		
		return $html;
	}

	public function siteSidebar()
	{
	}
	
	
	# INI RSS FUNCTION
	private function encodeURL($url)
	{
	   return preg_replace_callback('/[^\x20-\x7f]/', function($match) { return urlencode($match[0]); }, $url);
	}
	
	private function rss_createXML()
	{
		global $site;
		global $pages;
		global $url;

		// Amount of pages to show
		$numberOfItems = $this->getValue('rssNumberOfItems');

		// Get the list of public pages (sticky and static included)
		$list = $pages->getList
		(
			$pageNumber=1,
			$numberOfItems,
			$published=true,
			$static=true,
			$sticky=true,
			$draft=false,
			$scheduled=false
		);
        
		$xml = '<?xml version="1.0" encoding="UTF-8" ?>';
		$xml .= '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">';
		$xml .= '<channel>';
		$xml .= '<atom:link href="'.DOMAIN_BASE.'rss.xml" rel="self" type="application/rss+xml" />';
		$xml .= '<title>'.$site->title().'</title>';
		$xml .= '<link>'.$this->encodeURL($site->url()).'</link>';
		$xml .= '<description>'.$site->description().'</description>';
		$xml .= '<lastBuildDate>'.date(DATE_RSS).'</lastBuildDate>';


        #-1 == 'contentBreak' / 0 full / > 0 limit by its value                
        $contentStop='';
        $rssMaxNumChars=(int) $this->getValue('rssMaxNumChars');
		
        // Get keys of pages
		foreach ($list as $pageKey)
		{
			try 
			{
				// Create the page object from the page key
				$page = new Page($pageKey);
                
                if($this->getValue('rssNotShowingNoIndexPage')==true and $page->noindex() == 1) continue; #ignore noindex pages
                
                if($rssMaxNumChars == 0)
                   $contentStop=$page->content();
                
                if($rssMaxNumChars== -1)
                    $contentStop=$page->contentBreak();                
                    
                if($rssMaxNumChars > 0)
                    $contentStop=$this->HCLimitText($page->content(),$this->getValue('rssMaxNumChars'));
                
				$xml .= '<item>';
				$xml .= '<title>'.$page->title().'</title>';
				$xml .= '<link>'.$this->encodeURL($page->permalink()).'</link>';
				$xml .= '<description>'.Sanitize::html($contentStop).'</description>';
				$xml .= '<pubDate>'.date(DATE_RSS,strtotime($page->getValue('dateRaw'))).'</pubDate>';
				$xml .= '<guid isPermaLink="false">'.$page->uuid().'</guid>';
				$xml .= '</item>';
			} 
			catch (Exception $e) 
			{
				// Continue
			}
		}

		$xml .= '</channel>
				</rss>';

		// New DOM document
		$doc = new DOMDocument();
		$doc->formatOutput = true;
		$doc->loadXML($xml);
		
		return $doc->save($this->workspace().'rss.xml');
	}

	public function install($position=0)
	{
		parent::install($position);		
		return $this->rss_createXML();
	}

	public function post()
	{ 
		parent::post();		
		return $this->rss_createXML();		
	}

	public function afterPageCreate() { $this->rss_createXML(); }

	public function afterPageModify() { $this->rss_createXML();	 }	

	public function afterPageDelete() { $this->rss_createXML();	}	
	
	# END RSS FUNCTION
	
	
	# UTILS FUNCTIONS
    private function HCLimitText($string,$size=150) #  https://stackoverflow.com/questions/4258557/limit-text-length-in-php-and-provide-read-more-link
    {
        $string = strip_tags($string,$size);
        if (strlen($string) > $size) {
        
            // truncate string
            $stringCut = substr($string, 0, $size);
            $endPoint = strrpos($stringCut, ' ');
        
            //if the string doesn't contain any space then it will cut without word basis.
            $string = $endPoint ? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
            $string .= '...';
        }
        
        return $string;
    }
    
	private function baseHTML($pluginStatus,$pluginName,$pluginDesc,$pluginLabel,$content)
	{
		$html = '<div role="alert" class="plugin-info">'.
		'<div class="status">'.$pluginStatus.'</div>'.
		'<h2 class="plug-title">'.$pluginName.'</h2>'.
		'<h3 class="plug-desc">'.$pluginDesc.'</h3>'.
		'<div class="plug-content">
			<p><label>'.$pluginLabel.'</label></p> 
			  '.$content.'
		 </div>
		 </div>
		';	
		
		return $html;
	}
	
	private function OptionDisableEnable($var,$showstatus=true)
	{
		global $L;
		
		$html='';
		
		if($showstatus) $html.= '<span>'.$L->get('Plugin Status').'</span>';
		
		$html.= '
				<select name="'.$var.'" class="optionplugin">
					 <option value="true" '.($this->getValue($var)===true?'selected':'').'>'.$L->get('Enabled').'</option>
					 <option value="false" '.($this->getValue($var)===false?'selected':'').'>'.$L->get('Disabled').'</option>
				</select>';

		return $html;
	}
	
    private function OptionCheckBox($var)
	{
		$ck = ( $this->getValue($var) ? ' checked' : '' );	
		
		return PHP_EOL."<input type=\"hidden\" name=\"$var\" id=\"hidden_$var\" value=\"0\">".PHP_EOL.
		"<input type=\"checkbox\" name=\"$var\" id=\"$var\" value=\"1\"$ck>".PHP_EOL;		
	}
    
	private function CheckIfPageExists()
	{
		#copy from Bludits configs
		$decode = urldecode($_SERVER['REQUEST_URI']); 				
		$explode = explode('?', $decode);
		$uril = basename($explode[0]);	
		
		#defined in functions.php on bl-kernel
		if(buildPage($uril))
			return true;
		else 
			return false;
	}
	
    public function adminSidebar()
    {        
        global $login;
        
        if( $login->role() === 'admin' )	
        {
            $name='FS '.$this->name();
            return '<li class="nav-item"><a class="nav-link" href="' . HTML_PATH_ADMIN_ROOT . 'configure-plugin/'.get_class($this).'">' .$name. '</a></li>';
        }
    }	
}